# JARVIS proguard rules
-keep class com.jarvis.assistant.** { *; }
-dontwarn org.bytedeco.**
