package com.jarvis.assistant

import android.app.Application
import androidx.room.Room
import com.jarvis.assistant.data.JarvisDb

class JarvisApp : Application() {
    lateinit var db: JarvisDb
        private set

    override fun onCreate() {
        super.onCreate()
        db = Room.databaseBuilder(this, JarvisDb::class.java, "jarvis.db")
            .fallbackToDestructiveMigration()
            .build()
    }
}
