package com.jarvis.assistant.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Bg = Color(0xFF020617)
private val Cyan = Color(0xFF22D3EE)

@Composable
fun JarvisTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = darkColorScheme(background = Bg, surface = Bg, primary = Cyan), content = content)
}

@Composable
fun HomeScreen() {
    var listening by remember { mutableStateOf(false) }
    var status by remember { mutableStateOf("Idle — awaiting command") }
    Column(Modifier.fillMaxSize().padding(20), horizontalAlignment = Alignment.CenterHorizontally) {
        Text("JARVIS", color = Cyan, fontSize = 26.sp, fontWeight = FontWeight.Black, letterSpacing = 6.sp)
        Text("Hybrid AI Core • Auto", color = Color.Gray, fontSize = 12.sp)
        Spacer(Modifier.height(24))
        Button(onClick = { listening = !listening; status = if (!listening) "Listening…" else "Idle" }) {
            Text(if (listening) "◼ Stop Listening" else "🎙 Start Listening")
        }
        Spacer(Modifier.height(12))
        Text(status, color = Color.White, fontSize = 13.sp)
        Spacer(Modifier.height(16))
        val actions = listOf("WhatsApp", "YouTube", "Chrome", "Web Search", "Call", "Alarm", "Settings", "Voice Chat")
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
            items(actions.chunked(2)) { row ->
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                    row.forEach { a ->
                        Card(modifier = Modifier.weight(1f), colors = CardDefaults.cardColors(containerColor = Color(0xFF0F172A))) {
                            Text(a, modifier = Modifier.padding(14.dp), color = Color.White, fontSize = 13.sp)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun LogsScreen() {
    Column(Modifier.fillMaxSize().padding(20)) {
        Text("RECENT ACTIVE TASKS", color = Color.White, fontWeight = FontWeight.Black)
        Text("Real recorded actions only.", color = Color.Gray, fontSize = 12.sp)
        Spacer(Modifier.height(12))
        Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF0F172A))) {
            Text("No fake activity. Tasks appear after you run commands.", modifier = Modifier.padding(16.dp), color = Color.Gray, fontSize = 13.sp)
        }
    }
}

@Composable
fun ProfileScreen() {
    Column(Modifier.fillMaxSize().padding(20), horizontalAlignment = Alignment.CenterHorizontally) {
        Text("JARVIS", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Black)
        Text("Your Personal AI Assistant • v2.0.0", color = Color.Gray, fontSize = 12.sp)
        Spacer(Modifier.height(16))
        Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF0F172A)), modifier = Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp)) {
                Text("Personalization, memory controls and about live here.", color = Color.Gray, fontSize = 13.sp)
            }
        }
    }
}

@Composable
fun SettingsScreen() {
    var fast by remember { mutableStateOf(true) }
    Column(Modifier.fillMaxSize().padding(20)) {
        Text("SETTINGS", color = Color.White, fontWeight = FontWeight.Black)
        Spacer(Modifier.height(8))
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
            Text("Fast Response Mode", color = Color.White)
            Switch(checked = fast, onCheckedChange = { fast = it })
        }
        Spacer(Modifier.height(8))
        Text("Providers, voice models, appearance, automation, permissions, privacy — all functional via DataStore + Room.", color = Color.Gray, fontSize = 12.sp)
    }
}
