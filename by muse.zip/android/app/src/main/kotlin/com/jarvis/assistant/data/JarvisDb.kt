package com.jarvis.assistant.data

import androidx.room.*

@Entity(tableName = "tasks")
data class TaskEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val input: String,
    val status: String,
    val modeUsed: String,
    val result: String = "",
    val startedAt: Long = System.currentTimeMillis(),
    val completedAt: Long? = null
)

@Dao
interface TaskDao {
    @Query("SELECT * FROM tasks ORDER BY startedAt DESC LIMIT 100")
    suspend fun recent(): List<TaskEntity>

    @Insert
    suspend fun insert(t: TaskEntity): Long

    @Query("UPDATE tasks SET status=:status, completedAt=:at WHERE id=:id")
    suspend fun setStatus(id: Long, status: String, at: Long)

    @Query("DELETE FROM tasks")
    suspend fun clear()
}

@Database(entities = [TaskEntity::class], version = 1)
abstract class JarvisDb : RoomDatabase() {
    abstract fun tasks(): TaskDao
}
