package com.jarvis.assistant

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.jarvis.assistant.ui.HomeScreen
import com.jarvis.assistant.ui.LogsScreen
import com.jarvis.assistant.ui.ProfileScreen
import com.jarvis.assistant.ui.SettingsScreen
import com.jarvis.assistant.ui.JarvisTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            JarvisTheme {
                var tab by remember { mutableStateOf(0) }
                Scaffold(
                    containerColor = Color(0xFF020617),
                    bottomBar = {
                        NavigationBar(containerColor = Color(0xFF020617)) {
                            val items = listOf("Home" to "⌂", "Logs" to "☰", "Profile" to "◉", "Settings" to "⚙")
                            items.forEachIndexed { i, (label, icon) ->
                                NavigationBarItem(
                                    selected = tab == i,
                                    onClick = { tab = i },
                                    icon = { Text(icon, color = if (tab == i) Color(0xFF22D3EE) else Color.Gray) },
                                    label = { Text(label, color = if (tab == i) Color(0xFF22D3EE) else Color.Gray) }
                                )
                            }
                        }
                    }
                ) { pad ->
                    Box(Modifier.padding(pad).fillMaxSize().background(Color(0xFF020617))) {
                        when (tab) {
                            0 -> HomeScreen()
                            1 -> LogsScreen()
                            2 -> ProfileScreen()
                            3 -> SettingsScreen()
                        }
                    }
                }
            }
        }
    }
}
