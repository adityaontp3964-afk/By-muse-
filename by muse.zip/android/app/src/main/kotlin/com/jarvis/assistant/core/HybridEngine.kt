package com.jarvis.assistant.core

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.util.concurrent.TimeUnit

enum class AiMode { AUTO, ONLINE, OFFLINE }

data class ProviderConfig(
    val name: String,
    val type: String,
    val baseUrl: String,
    val model: String,
    val apiKey: String
)

data class TaskStep(val label: String, var status: String = "pending", var detail: String = "")

data class EngineResult(
    val response: String,
    val modeUsed: String,
    val intent: String,
    val steps: List<TaskStep>
)

/**
 * True hybrid engine:
 * AUTO -> online provider when network + config present, else offline llama.cpp model.
 * Online failure -> offline fallback if local model installed. Never fakes success.
 */
class HybridEngine(
    private val network: NetworkMonitor,
    private val secureStore: SecureStore,
    private val localLlm: LocalLlm,
    private val intentParser: IntentParser = IntentParser()
) {
    private val http = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .build()

    suspend fun handle(input: String, mode: AiMode): EngineResult = withContext(Dispatchers.IO) {
        val parsed = intentParser.parse(input)

        if (parsed.needsClarification) {
            return@withContext EngineResult(
                response = parsed.clarification,
                modeUsed = "offline",
                intent = parsed.intent,
                steps = listOf(TaskStep("Awaiting clarification", "pending"))
            )
        }

        // Automation intents execute locally first (fast), narration may use online LLM.
        val provider = secureStore.activeProvider()
        val wantOnline = mode == AiMode.ONLINE || mode == AiMode.AUTO
        val canOnline = wantOnline && provider != null && provider.apiKey.isNotBlank() && network.isOnline()

        if (parsed.isAutomation || mode == AiMode.OFFLINE || !canOnline) {
            if (!parsed.isAutomation && canOnline) {
                // conversational + online available -> try online
                val online = tryOnline(input, provider!!)
                if (online != null) return@withContext online
            }
            val exec = AndroidActions.describe(parsed)
            val reply = localLlm.reply(input, parsed)
            return@withContext EngineResult(reply, "offline", parsed.intent, exec)
        }

        // ONLINE path with offline fallback
        tryOnline(input, provider!!)?.let { return@withContext it }
        val fallback = localLlm.reply(input, parsed)
        EngineResult(
            fallback, "offline", parsed.intent,
            listOf(TaskStep("Online failed, offline fallback used", "completed"))
        )
    }

    private fun tryOnline(input: String, p: ProviderConfig): EngineResult? {
        return try {
            val base = when {
                p.baseUrl.isNotBlank() -> p.baseUrl.trimEnd('/')
                p.type == "groq" -> "https://api.groq.com/openai/v1"
                else -> "https://api.openai.com/v1"
            }
            val body = JSONObject()
                .put("model", p.model)
                .put("max_tokens", 280)
                .put("temperature", 0.6)
                .put("messages", org.json.JSONArray().apply {
                    put(JSONObject().put("role", "system").put("content", "You are JARVIS, a loyal phone assistant. Concise, helpful. Never expose keys."))
                    put(JSONObject().put("role", "user").put("content", input))
                }).toString()
            val req = Request.Builder()
                .url("$base/chat/completions")
                .addHeader("Authorization", "Bearer ${p.apiKey}")
                .post(body.toRequestBody("application/json".toMediaType()))
                .build()
            http.newCall(req).execute().use { resp ->
                if (!resp.isSuccessful) return null
                val text = JSONObject(resp.body!!.string())
                    .getJSONArray("choices").getJSONObject(0)
                    .getJSONObject("message").getString("content")
                EngineResult(text, "online", "conversation", listOf(TaskStep("Online reasoning via ${p.model}", "completed")))
            }
        } catch (_: Exception) { null }
    }
}
