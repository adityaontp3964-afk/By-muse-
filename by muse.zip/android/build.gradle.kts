// Top-level JARVIS build file — verified combo:
// AGP 8.5.2 + Kotlin 1.9.24 + KSP 1.9.24-1.0.20 + Compose Compiler 1.5.14
plugins {
    id("com.android.application") version "8.5.2" apply false
    id("org.jetbrains.kotlin.android") version "1.9.24" apply false
    id("com.google.devtools.ksp") version "1.9.24-1.0.20" apply false
}
