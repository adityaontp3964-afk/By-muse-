import { db } from "@/db";
import { messages } from "@/db/schema";
import { desc } from "drizzle-orm";

export const dynamic = "force-dynamic";

export async function GET(req: Request) {
  try {
    const url = new URL(req.url);
    const limit = Math.min(Number(url.searchParams.get("limit") || "100"), 300);
    const rows = await db.select().from(messages).orderBy(desc(messages.createdAt)).limit(limit);
    return Response.json({ messages: rows.reverse() });
  } catch (e) {
    return Response.json({ messages: [], error: String(e) }, { status: 500 });
  }
}

export async function DELETE() {
  try {
    await db.delete(messages);
    return Response.json({ ok: true });
  } catch (e) {
    return Response.json({ error: String(e) }, { status: 500 });
  }
}
