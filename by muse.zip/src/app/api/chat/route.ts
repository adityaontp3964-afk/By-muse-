import { db } from "@/db";
import { providers, tasks, messages } from "@/db/schema";
import { eq } from "drizzle-orm";
import { parseIntent, offlineReply } from "@/lib/jarvis-brain";

export const dynamic = "force-dynamic";

function baseFor(type: string, baseUrl: string) {
  if (baseUrl?.trim()) return baseUrl.trim().replace(/\/$/, "");
  if (type === "groq") return "https://api.groq.com/openai/v1";
  return "https://api.openai.com/v1";
}

export async function POST(req: Request) {
  try {
    const body = await req.json();
    const input: string = String(body.input || "").slice(0, 2000);
    const mode: string = body.mode || "auto";
    const ctx = body.context || {};
    const settings = body.settings || {};
    const pending = body.pending || null;
    if (!input.trim()) return Response.json({ error: "Empty input" }, { status: 400 });

    const parsed = parseIntent(input, {
      lastApp: ctx.lastApp,
      lastQuery: ctx.lastQuery,
      pending,
    });

    // If needs clarification -> create task (running, awaiting input) and reply clarification
    if (parsed.needsClarification && parsed.clarification) {
      const inserted = await db
        .insert(tasks)
        .values({
          title: parsed.actionLabel,
          input,
          status: "running",
          modeUsed: "offline",
          steps: [{ label: "Awaiting clarification", status: "pending", detail: parsed.clarification, at: new Date().toISOString() }],
          result: parsed.clarification,
        })
        .returning();
      await db.insert(messages).values([
        { role: "user", content: input, modeUsed: "offline" },
        { role: "assistant", content: parsed.clarification, modeUsed: "offline", taskId: inserted[0].id },
      ]);
      return Response.json({
        response: parsed.clarification,
        intent: parsed.intent,
        entities: parsed.entities,
        steps: parsed.steps,
        needsClarification: true,
        pending: parsed,
        taskId: inserted[0].id,
        modeUsed: "offline",
        webUrl: parsed.webUrl,
        requiresConfirmation: parsed.requiresConfirmation,
      });
    }

    // Decide mode: online if mode online/auto and active provider exists
    let activeProvider: typeof providers.$inferSelect | null = null;
    if (settings.activeProviderId) {
      const rows = await db.select().from(providers).where(eq(providers.id, Number(settings.activeProviderId)));
      activeProvider = rows[0] ?? null;
    } else {
      const rows = await db.select().from(providers).where(eq(providers.isActive, true));
      activeProvider = rows[0] ?? null;
    }

    const wantOnline = mode === "online" || mode === "auto";
    const canGoOnline = wantOnline && activeProvider && activeProvider.apiKey && activeProvider.model;
    const forceOffline = mode === "offline" || !canGoOnline;

    // Non-conversational automation intents: execute locally (fast), optionally enrich with online LLM
    const isAutomation = parsed.intent !== "conversation" && parsed.intent !== "unknown";

    if (forceOffline || isAutomation) {
      let response = offlineReply(input, parsed);
      let modeUsed = "offline";
      // If online available + fastResponse off + conversation? enrich automation narration via LLM
      if (canGoOnline && parsed.intent === "conversation" && !forceOffline) {
        // fall through to online below
      } else {
        // For automation with online available and mode auto: optionally get short narration, but keep fast
        const steps = parsed.steps.map((s, i) => ({
          label: s,
          status: i === 0 ? "completed" : "completed",
          detail: "Verified locally",
          at: new Date().toISOString(),
        }));
        const inserted = await db
          .insert(tasks)
          .values({
            title: parsed.actionLabel,
            input,
            status: "completed",
            modeUsed,
            steps,
            result: response,
            completedAt: new Date(),
          })
          .returning();
        await db.insert(messages).values([
          { role: "user", content: input, modeUsed, taskId: inserted[0].id },
          { role: "assistant", content: response, modeUsed, taskId: inserted[0].id },
        ]);
        // side: if automation produced webUrl, append hint
        return Response.json({
          response,
          intent: parsed.intent,
          entities: parsed.entities,
          steps: parsed.steps,
          needsClarification: false,
          pending: null,
          taskId: inserted[0].id,
          modeUsed,
          webUrl: parsed.webUrl,
          androidIntent: parsed.androidIntent,
          requiresConfirmation: parsed.requiresConfirmation,
        });
      }
    }

    // ONLINE path
    if (!activeProvider) {
      const fallback = offlineReply(input, parsed);
      const inserted = await db
        .insert(tasks)
        .values({
          title: parsed.actionLabel,
          input,
          status: "completed",
          modeUsed: "offline",
          steps: [{ label: "Offline fallback (no provider configured)", status: "completed", at: new Date().toISOString() }],
          result: fallback,
          completedAt: new Date(),
        })
        .returning();
      await db.insert(messages).values([
        { role: "user", content: input, modeUsed: "offline" },
        { role: "assistant", content: fallback + " Tip: configure a provider in Settings → AI to unlock online reasoning.", modeUsed: "offline", taskId: inserted[0].id },
      ]);
      return Response.json({
        response: fallback + " Tip: configure a provider in Settings → AI to unlock online reasoning.",
        intent: parsed.intent,
        entities: parsed.entities,
        steps: parsed.steps,
        taskId: inserted[0].id,
        modeUsed: "offline",
        webUrl: parsed.webUrl,
      });
    }

    try {
      const base = baseFor(activeProvider.type, activeProvider.baseUrl);
      const perf = settings.performance || "fast";
      const maxTokens = perf === "max" ? 300 : perf === "fast" ? 220 : 400;
      const temperature = settings.responseStyle === "concise" ? 0.4 : 0.7;
      const sysPrompt = `You are ${settings.assistantName || "JARVIS"}, a personal AI phone assistant. User calls you ${settings.assistantName || "JARVIS"}. Address user as ${settings.userName || "Sir"}. Speak ${parsed.language === "hi" ? "Hindi" : parsed.language === "hinglish" ? "Hinglish (Hindi in Roman script mixed with English)" : "English"}. Style: ${settings.responseStyle || "jarvis"} — concise, loyal, Iron-Man JARVIS tone but helpful. Keep answer ${settings.responseLength || "medium"} length (${maxTokens} tokens max). Detected intent: ${parsed.intent} ${JSON.stringify(parsed.entities)}. If automation intent, confirm what was done and next step. Never expose API keys. Never claim to have sent messages silently.`;
      const ctrl = new AbortController();
      const timer = setTimeout(() => ctrl.abort(), perf === "max" ? 20000 : 30000);
      const resp = await fetch(`${base}/chat/completions`, {
        method: "POST",
        headers: { Authorization: `Bearer ${activeProvider.apiKey}`, "Content-Type": "application/json" },
        body: JSON.stringify({
          model: activeProvider.model,
          messages: [
            { role: "system", content: sysPrompt },
            { role: "user", content: input },
          ],
          max_tokens: maxTokens,
          temperature,
          stream: false,
        }),
        signal: ctrl.signal,
      });
      clearTimeout(timer);
      if (!resp.ok) {
        const errText = (await resp.text()).slice(0, 500);
        // offline fallback
        const fallback = offlineReply(input, parsed);
        const inserted = await db
          .insert(tasks)
          .values({
            title: parsed.actionLabel,
            input,
            status: "completed",
            modeUsed: "offline",
            steps: [{ label: `Online failed (${resp.status}), offline fallback used`, status: "completed", at: new Date().toISOString() }],
            result: fallback,
            error: errText,
            completedAt: new Date(),
          })
          .returning();
        await db.insert(messages).values([
          { role: "user", content: input, modeUsed: "offline" },
          { role: "assistant", content: fallback, modeUsed: "offline", taskId: inserted[0].id },
        ]);
        return Response.json({
          response: fallback,
          intent: parsed.intent,
          entities: parsed.entities,
          steps: parsed.steps,
          taskId: inserted[0].id,
          modeUsed: "offline",
          webUrl: parsed.webUrl,
          onlineError: `Provider error ${resp.status}: ${errText.slice(0, 200)}`,
        });
      }
      const data = await resp.json();
      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      const text: string = (data as any)?.choices?.[0]?.message?.content || offlineReply(input, parsed);
      const inserted = await db
        .insert(tasks)
        .values({
          title: parsed.actionLabel,
          input,
          status: "completed",
          modeUsed: "online",
          steps: [
            { label: "Intent detected: " + parsed.intent, status: "completed", at: new Date().toISOString() },
            { label: `Online reasoning via ${activeProvider.name} (${activeProvider.model})`, status: "completed", at: new Date().toISOString() },
            ...(parsed.steps.map((s) => ({ label: s, status: "completed", at: new Date().toISOString() })) as { label: string; status: string; at: string }[]),
          ],
          result: text,
          completedAt: new Date(),
        })
        .returning();
      await db.insert(messages).values([
        { role: "user", content: input, modeUsed: "online" },
        { role: "assistant", content: text, modeUsed: "online", taskId: inserted[0].id },
      ]);
      return Response.json({
        response: text,
        intent: parsed.intent,
        entities: parsed.entities,
        steps: parsed.steps,
        taskId: inserted[0].id,
        modeUsed: "online",
        webUrl: parsed.webUrl,
        androidIntent: parsed.androidIntent,
        requiresConfirmation: parsed.requiresConfirmation,
      });
    } catch (e) {
      const fallback = offlineReply(input, parsed);
      const inserted = await db
        .insert(tasks)
        .values({
          title: parsed.actionLabel,
          input,
          status: "completed",
          modeUsed: "offline",
          steps: [{ label: "Online exception, offline fallback", status: "completed", at: new Date().toISOString() }],
          result: fallback,
          error: String(e),
          completedAt: new Date(),
        })
        .returning();
      return Response.json({
        response: fallback,
        intent: parsed.intent,
        entities: parsed.entities,
        steps: parsed.steps,
        taskId: inserted[0].id,
        modeUsed: "offline",
        webUrl: parsed.webUrl,
        onlineError: String(e),
      });
    }
  } catch (e) {
    return Response.json({ error: String(e) }, { status: 500 });
  }
}
