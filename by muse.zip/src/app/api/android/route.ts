export const dynamic = "force-dynamic";

export async function GET() {
  return Response.json({
    app: "JARVIS — Your Personal AI Assistant",
    version: "2.0.0",
    package: "com.jarvis.assistant",
    minSdk: 26,
    targetSdk: 34,
    stack: ["Kotlin", "Jetpack Compose", "Material3", "Coroutines", "Room", "DataStore", "Keystore", "WorkManager", "ForegroundService", "AccessibilityService", "llama.cpp", "Vosk", "Piper"],
    projectRoot: "/android",
    workflow: ".github/workflows/build-apk.yml",
    branches: ["main", "manual dispatch"],
    gradleTasks: ["assembleDebug", "assembleRelease"],
    artifact: "app-debug.apk / app-release.apk",
    howToBuild: [
      "1. Push this repo to GitHub (include /android + workflow).",
      "2. Open GitHub → Actions → 'Build JARVIS APK' → Run workflow.",
      "3. Download 'jarvis-apk' artifact and install on Android 8.0+.",
      "4. Or locally: cd android && ./gradlew assembleDebug",
    ],
    notes: "Web preview above is the live hybrid control plane. Native APK is built by CI from /android sources.",
  });
}
