import { db } from "@/db";
import { providers } from "@/db/schema";
import { eq } from "drizzle-orm";

export const dynamic = "force-dynamic";

function baseFor(type: string, baseUrl: string) {
  if (baseUrl?.trim()) return baseUrl.trim().replace(/\/$/, "");
  if (type === "groq") return "https://api.groq.com/openai/v1";
  return "https://api.openai.com/v1";
}

export async function POST(req: Request) {
  try {
    const body = await req.json();
    let { baseUrl, model, apiKey, type, id } = body as {
      baseUrl?: string;
      model?: string;
      apiKey?: string;
      type?: string;
      id?: number;
    };
    if (id && (!apiKey || !model)) {
      const rows = await db.select().from(providers).where(eq(providers.id, Number(id)));
      const p = rows[0];
      if (!p) return Response.json({ ok: false, error: "Provider not found" }, { status: 404 });
      baseUrl = baseUrl || p.baseUrl;
      model = model || p.model;
      apiKey = apiKey || p.apiKey;
      type = type || p.type;
    }
    if (!apiKey || !model) {
      return Response.json({ ok: false, error: "API key and model are required" }, { status: 400 });
    }
    const base = baseFor(type || "custom", baseUrl || "");
    const ctrl = new AbortController();
    const timer = setTimeout(() => ctrl.abort(), 20000);
    try {
      const resp = await fetch(`${base}/models`, {
        headers: { Authorization: `Bearer ${apiKey}` },
        signal: ctrl.signal,
      });
      clearTimeout(timer);
      if (resp.ok) {
        const data = await resp.json().catch(() => ({}));
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        const list: any[] = (data as any)?.data ?? [];
        const found = list.length === 0 ? true : list.some((m) => m.id === model || m.id?.includes?.(String(model).split("-")[0]));
        if (id) {
          await db
            .update(providers)
            .set({ lastTestOk: found, lastTestedAt: new Date() })
            .where(eq(providers.id, Number(id)));
        }
        return Response.json({
          ok: found,
          message: found ? `Connected. Model "${model}" is available.` : `Connected, but model "${model}" was not listed. Check model name.`,
          models: list.slice(0, 30).map((m) => m.id),
        });
      }
      // fallback: try chat completion with max_tokens 1
      const ctrl2 = new AbortController();
      const t2 = setTimeout(() => ctrl2.abort(), 20000);
      const chat = await fetch(`${base}/chat/completions`, {
        method: "POST",
        headers: { Authorization: `Bearer ${apiKey}`, "Content-Type": "application/json" },
        body: JSON.stringify({ model, messages: [{ role: "user", content: "ping" }], max_tokens: 1 }),
        signal: ctrl2.signal,
      });
      clearTimeout(t2);
      const ok = chat.ok;
      const errText = ok ? "" : (await chat.text()).slice(0, 400);
      if (id) {
        await db.update(providers).set({ lastTestOk: ok, lastTestedAt: new Date() }).where(eq(providers.id, Number(id)));
      }
      return Response.json({
        ok,
        message: ok ? `Connected. Model "${model}" responded.` : `Connection failed (${chat.status}): ${errText}`,
      });
    } catch (e) {
      clearTimeout(timer);
      return Response.json({ ok: false, error: `Network error: ${String(e)}` }, { status: 200 });
    }
  } catch (e) {
    return Response.json({ ok: false, error: String(e) }, { status: 500 });
  }
}
