import { db } from "@/db";
import { tasks } from "@/db/schema";
import { desc } from "drizzle-orm";

export const dynamic = "force-dynamic";

export async function GET(req: Request) {
  try {
    const url = new URL(req.url);
    const limit = Math.min(Number(url.searchParams.get("limit") || "50"), 200);
    const rows = await db.select().from(tasks).orderBy(desc(tasks.createdAt)).limit(limit);
    return Response.json({ tasks: rows });
  } catch (e) {
    return Response.json({ tasks: [], error: String(e) }, { status: 500 });
  }
}

export async function DELETE() {
  try {
    await db.delete(tasks);
    return Response.json({ ok: true });
  } catch (e) {
    return Response.json({ error: String(e) }, { status: 500 });
  }
}
