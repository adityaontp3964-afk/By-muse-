"use client";

import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { DEFAULT_SETTINGS, type JarvisSettings } from "@/lib/settings";
import { speak, stopSpeak, createRecognizer } from "@/lib/voice";

export const dynamic = "force-dynamic";

interface Provider {
  id: number;
  name: string;
  type: string;
  baseUrl: string;
  model: string;
  apiKeyMasked: string;
  isActive: boolean;
  lastTestOk?: boolean | null;
}
interface Task {
  id: number;
  title: string;
  input: string;
  status: string;
  modeUsed: string;
  steps: { label: string; status: string; detail?: string; at?: string }[];
  result: string;
  error: string;
  startedAt: string;
  completedAt: string | null;
}
interface ChatMsg {
  id: number;
  role: string;
  content: string;
  modeUsed?: string;
  createdAt: string;
}
interface QA {
  id: number;
  actionKey: string;
  label: string;
  icon: string;
  enabled: boolean;
  sortOrder: number;
}
interface DevModel {
  id: number;
  kind: string;
  name: string;
  description: string;
  sizeMb: number;
  downloadUrl: string;
  status: string;
  progress: number;
  isActive: boolean;
}

const ACCENTS: Record<string, { core: string; ring: string; text: string; btn: string }> = {
  cyan: { core: "from-cyan-400 via-sky-500 to-blue-600", ring: "border-cyan-400/40", text: "text-cyan-300", btn: "bg-cyan-500 hover:bg-cyan-400 text-slate-950" },
  blue: { core: "from-blue-400 via-indigo-500 to-cyan-500", ring: "border-blue-400/40", text: "text-blue-300", btn: "bg-blue-500 hover:bg-blue-400 text-white" },
  violet: { core: "from-violet-400 via-fuchsia-500 to-indigo-600", ring: "border-violet-400/40", text: "text-violet-300", btn: "bg-violet-500 hover:bg-violet-400 text-white" },
  emerald: { core: "from-emerald-300 via-teal-400 to-cyan-500", ring: "border-emerald-300/40", text: "text-emerald-300", btn: "bg-emerald-400 hover:bg-emerald-300 text-slate-950" },
  amber: { core: "from-amber-300 via-orange-400 to-yellow-500", ring: "border-amber-300/40", text: "text-amber-300", btn: "bg-amber-400 hover:bg-amber-300 text-slate-950" },
};

function iconFor(key: string) {
  switch (key) {
    case "message": return "💬";
    case "play": return "▶";
    case "globe": return "🌐";
    case "search": return "🔍";
    case "phone": return "📞";
    case "chat": return "✉";
    case "clock": return "⏰";
    case "gear": return "⚙";
    case "mic": return "🎙";
    default: return "⚡";
  }
}

export default function JarvisApp() {
  const [booted, setBooted] = useState(false);
  const [tab, setTab] = useState<"home" | "logs" | "profile" | "settings">("home");
  const [settings, setSettings] = useState<JarvisSettings>(DEFAULT_SETTINGS);
  const [settingsLoaded, setSettingsLoaded] = useState(false);
  const [providers, setProviders] = useState<Provider[]>([]);
  const [tasks, setTasks] = useState<Task[]>([]);
  const [chatMsgs, setChatMsgs] = useState<ChatMsg[]>([]);
  const [quickActions, setQuickActions] = useState<QA[]>([]);
  const [models, setModels] = useState<DevModel[]>([]);
  const [input, setInput] = useState("");
  const [busy, setBusy] = useState(false);
  const [listening, setListening] = useState(false);
  const [transcript, setTranscript] = useState("");
  const [speaking, setSpeaking] = useState(false);
  const [conversationOpen, setConversationOpen] = useState(false);
  const [pending, setPending] = useState<Record<string, unknown> | null>(null);
  const [confirmCard, setConfirmCard] = useState<{ title: string; contact: string; message: string; webUrl?: string } | null>(null);
  const [lastContext, setLastContext] = useState<{ lastApp?: string; lastQuery?: string }>({});
  const [currentTask, setCurrentTask] = useState<string>("Idle — awaiting command");
  const [lastResponse, setLastResponse] = useState<string>("Systems online. I am JARVIS, ready to assist.");
  const [activeModeUsed, setActiveModeUsed] = useState<string>("hybrid");
  const [online, setOnline] = useState(true);
  const [settingsTab, setSettingsTab] = useState("AI");
  const [logFilter, setLogFilter] = useState("all");
  const [selectedTask, setSelectedTask] = useState<Task | null>(null);
  const [showProviderForm, setShowProviderForm] = useState(false);
  const [editingProvider, setEditingProvider] = useState<Partial<Provider> & { apiKey?: string; id?: number }>({ name: "", type: "groq", baseUrl: "", model: "", apiKey: "" });
  const [testingId, setTestingId] = useState<number | null>(null);
  const [testMsg, setTestMsg] = useState("");
  const [voices, setVoices] = useState<SpeechSynthesisVoice[]>([]);
  const [notice, setNotice] = useState("");
  const [wakeListening, setWakeListening] = useState(false);

  const recogRef = useRef<{ stop: () => void; start: () => void; abort: () => void } | null>(null);
  const wakeRef = useRef<{ stop: () => void; start: () => void; abort: () => void } | null>(null);
  const chatEndRef = useRef<HTMLDivElement>(null);
  const saveTimer = useRef<ReturnType<typeof setTimeout> | null>(null);

  const accent = ACCENTS[settings.accent] ?? ACCENTS.cyan;
  const animOff = settings.animation === "off";
  const reducedAnim = settings.animation === "reduced";
  const fontScale = settings.fontSize === "small" ? "text-[13px]" : settings.fontSize === "large" ? "text-[17px]" : "text-[15px]";

  const effectiveMode = useMemo(() => {
    if (settings.aiMode === "online") return "online";
    if (settings.aiMode === "offline") return "offline";
    return online ? "online" : "offline";
  }, [settings.aiMode, online]);

  useEffect(() => {
    const t = setTimeout(() => setBooted(true), 2400);
    return () => clearTimeout(t);
  }, []);

  useEffect(() => {
    setOnline(typeof navigator !== "undefined" ? navigator.onLine : true);
    const on = () => setOnline(true);
    const off = () => setOnline(false);
    window.addEventListener("online", on);
    window.addEventListener("offline", off);
    return () => {
      window.removeEventListener("online", on);
      window.removeEventListener("offline", off);
    };
  }, []);

  useEffect(() => {
    if ("speechSynthesis" in window) {
      const load = () => setVoices(window.speechSynthesis.getVoices());
      load();
      window.speechSynthesis.onvoiceschanged = load;
    }
  }, []);

  const loadAll = useCallback(async () => {
    try {
      const [s, p, t, m, q, mod] = await Promise.all([
        fetch("/api/settings").then((r) => r.json()).catch(() => null),
        fetch("/api/providers").then((r) => r.json()).catch(() => null),
        fetch("/api/tasks?limit=60").then((r) => r.json()).catch(() => null),
        fetch("/api/messages?limit=120").then((r) => r.json()).catch(() => null),
        fetch("/api/quick-actions").then((r) => r.json()).catch(() => null),
        fetch("/api/models").then((r) => r.json()).catch(() => null),
      ]);
      if (s?.settings) {
        setSettings({ ...DEFAULT_SETTINGS, ...s.settings });
        setSettingsLoaded(true);
      } else setSettingsLoaded(true);
      if (p?.providers) setProviders(p.providers);
      if (t?.tasks) setTasks(t.tasks);
      if (m?.messages) setChatMsgs(m.messages);
      if (q?.actions) setQuickActions(q.actions);
      if (mod?.models) setModels(mod.models);
    } catch {
      setSettingsLoaded(true);
    }
  }, []);

  useEffect(() => {
    loadAll();
  }, [loadAll]);

  useEffect(() => {
    chatEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [chatMsgs, conversationOpen]);

  function persist(next: JarvisSettings) {
    setSettings(next);
    if (saveTimer.current) clearTimeout(saveTimer.current);
    saveTimer.current = setTimeout(() => {
      fetch("/api/settings", { method: "PUT", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ settings: next }) }).catch(() => {});
    }, 600);
  }

  function update<K extends keyof JarvisSettings>(k: K, v: JarvisSettings[K]) {
    persist({ ...settings, [k]: v });
  }

  function flash(msg: string) {
    setNotice(msg);
    setTimeout(() => setNotice(""), 3200);
  }

  const doSpeak = useCallback(
    (text: string) => {
      if (!settings.voiceOutput) return;
      try {
        setSpeaking(true);
        const ok = speak(text.slice(0, 600), {
          rate: settings.speechRate,
          pitch: settings.speechPitch,
          volume: settings.speechVolume,
          lang: settings.speechLang,
          voiceURI: settings.speechVoice || undefined,
        });
        if (!ok) setSpeaking(false);
        else setTimeout(() => setSpeaking(false), Math.min(12000, 1500 + text.length * 45));
      } catch {
        setSpeaking(false);
      }
    },
    [settings]
  );

  async function refreshTasksMsgs() {
    const [t, m] = await Promise.all([
      fetch("/api/tasks?limit=60").then((r) => r.json()).catch(() => null),
      fetch("/api/messages?limit=120").then((r) => r.json()).catch(() => null),
    ]);
    if (t?.tasks) setTasks(t.tasks);
    if (m?.messages) setChatMsgs(m.messages);
  }

  async function sendCommand(raw?: string) {
    const text = (raw ?? input).trim();
    if (!text || busy) return;
    setInput("");
    setTranscript("");
    setBusy(true);
    setCurrentTask(`Working: ${text.slice(0, 60)}`);
    setConversationOpen(true);
    // optimistic user msg
    const tempUser: ChatMsg = { id: Date.now(), role: "user", content: text, createdAt: new Date().toISOString() };
    setChatMsgs((p) => [...p, tempUser]);
    try {
      const modeToSend = settings.aiMode === "auto" ? "auto" : settings.aiMode;
      const res = await fetch("/api/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          input: text,
          mode: modeToSend,
          context: lastContext,
          pending,
          settings: {
            activeProviderId: settings.activeProviderId,
            performance: settings.performance,
            responseStyle: settings.responseStyle,
            responseLength: settings.responseLength,
            assistantName: settings.assistantName,
            userName: settings.userName,
          },
        }),
      });
      const data = await res.json();
      if (data.error) throw new Error(data.error);
      const assistant: ChatMsg = {
        id: Date.now() + 1,
        role: "assistant",
        content: data.response,
        modeUsed: data.modeUsed,
        createdAt: new Date().toISOString(),
      };
      setChatMsgs((p) => [...p, assistant]);
      setLastResponse(data.response);
      setActiveModeUsed(data.modeUsed || "offline");
      setPending(data.needsClarification ? data.pending ?? { raw: text } : null);
      // update context for follow-ups
      if (data.entities?.query) setLastContext((c) => ({ ...c, lastQuery: data.entities.query }));
      if (data.intent === "open_app" && data.entities?.app) {
        setLastContext((c) => ({ ...c, lastApp: data.entities.app }));
      }
      if (data.intent === "youtube_search" && data.entities?.query) {
        setLastContext((c) => ({ ...c, lastApp: "youtube", lastQuery: data.entities.query }));
      }
      // confirmation card for whatsapp/call (preserve exact message)
      if (data.requiresConfirmation && (data.intent === "whatsapp_message" || data.intent === "phone_call")) {
        const contact = data.entities?.contact || "contact";
        const message = data.entities?.message || "";
        if (data.intent === "whatsapp_message" && message) {
          setConfirmCard({ title: `WhatsApp to ${contact}`, contact, message, webUrl: data.webUrl });
        } else if (data.intent === "phone_call") {
          setConfirmCard({ title: `Call ${contact}`, contact, message: `Place a phone call to ${contact}? This requires your explicit confirmation.`, webUrl: undefined });
        }
      }
      // auto-open webUrl for search/open intents (new tab) — but not for whatsapp until confirmed
      if (data.webUrl && !data.requiresConfirmation && (data.intent === "web_search" || data.intent === "youtube_search" || data.intent === "open_app")) {
        if (settings.automationEnabled) {
          window.open(data.webUrl, "_blank", "noopener");
        }
      }
      setCurrentTask(`Done: ${data.intent} (${data.modeUsed})`);
      doSpeak(data.response);
      await refreshTasksMsgs();
    } catch (e) {
      const msg = `Sorry, that failed: ${String(e).slice(0, 200)}`;
      setChatMsgs((p) => [...p, { id: Date.now() + 2, role: "assistant", content: msg, createdAt: new Date().toISOString() }]);
      setCurrentTask("Failed — see Logs");
      flash(msg);
    } finally {
      setBusy(false);
    }
  }

  function startListening() {
    if (listening) return;
    if (!settings.voiceInput) {
      flash("Voice input is disabled. Enable it in Settings → Voice.");
      return;
    }
    const rec = createRecognizer(settings.speechLang || "en-IN", {
      onResult: (text, isFinal) => {
        setTranscript(text);
        if (isFinal && text.trim()) {
          stopListening();
          sendCommand(text.trim());
        }
      },
      onError: (msg) => {
        if (msg.includes("not-allowed") || msg.includes("denied")) {
          flash("Microphone blocked. Allow mic permission and try again.");
        } else if (msg.includes("no-speech")) {
          flash("No speech detected. Try again, Sir.");
        } else {
          flash(`Listening issue: ${msg}. Type instead, or install offline voice model.`);
        }
        setListening(false);
      },
      onEnd: () => setListening(false),
      onStart: () => setListening(true),
    });
    if (!rec) {
      flash("Speech recognition not supported in this browser. Type your command — offline voice models install inside the Android app.");
      return;
    }
    recogRef.current = rec;
    try {
      rec.start();
      setListening(true);
      if (settings.haptics && navigator.vibrate) navigator.vibrate(20);
    } catch {
      flash("Could not start microphone.");
    }
  }

  function stopListening() {
    try {
      recogRef.current?.stop();
    } catch {}
    setListening(false);
  }

  function startWakeWord() {
    if (wakeListening) {
      try { wakeRef.current?.stop(); } catch {}
      setWakeListening(false);
      return;
    }
    const phrase = (settings.wakePhrase || "hey jarvis").toLowerCase();
    const rec = createRecognizer("en-IN", {
      onResult: (text) => {
        if (text.toLowerCase().includes(phrase) || text.toLowerCase().includes("jarvis")) {
          flash("Wake word detected — listening…");
          try { wakeRef.current?.stop(); } catch {}
          setWakeListening(false);
          startListening();
        }
      },
      onError: () => {},
      onEnd: () => {
        if (wakeListening) {
          try { wakeRef.current?.start(); } catch {}
        }
      },
    });
    if (!rec) {
      flash("Wake-word needs browser speech support. Use Start Listening instead.");
      return;
    }
    wakeRef.current = rec;
    try {
      rec.start();
      setWakeListening(true);
      flash(`Wake-word armed: "${settings.wakePhrase}". Say it to wake me.`);
    } catch {
      flash("Could not arm wake-word.");
    }
  }

  async function handleQuick(key: string, label: string) {
    if (settings.haptics && navigator.vibrate) navigator.vibrate(10);
    const map: Record<string, string> = {
      whatsapp: "Rahul ko WhatsApp message bhejo",
      youtube: "YouTube kholo",
      chrome: "Chrome kholo",
      websearch: "Google par search karo JARVIS features",
      call: "Call Rahul",
      message: "Send WhatsApp message to Rahul",
      alarm: "Set alarm for 7 AM",
      settings: "Settings kholo",
      voice: "__voice__",
      custom: "__custom__",
    };
    if (key === "voice") {
      startListening();
      return;
    }
    if (key === "custom") {
      setConversationOpen(true);
      flash("Type any custom command — e.g. 'Arijit Singh songs search karo'.");
      return;
    }
    await sendCommand(map[key] || label);
  }

  async function saveProviderForm() {
    if (!editingProvider.name?.trim() || !editingProvider.model?.trim()) {
      flash("Provider name and model are required.");
      return;
    }
    const payload = {
      name: editingProvider.name,
      type: editingProvider.type || "groq",
      baseUrl: editingProvider.baseUrl || "",
      model: editingProvider.model,
      apiKey: editingProvider.apiKey || "",
      isActive: providers.length === 0 ? true : undefined,
    };
    try {
      let res;
      if (editingProvider.id) {
        res = await fetch(`/api/providers/${editingProvider.id}`, {
          method: "PATCH",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(payload),
        });
      } else {
        res = await fetch("/api/providers", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(payload),
        });
      }
      const data = await res.json();
      if (data.error) throw new Error(data.error);
      const list = await fetch("/api/providers").then((r) => r.json());
      setProviders(list.providers || []);
      setShowProviderForm(false);
      setEditingProvider({ name: "", type: "groq", baseUrl: "", model: "", apiKey: "" });
      flash(editingProvider.id ? "Provider updated." : "Provider saved. Test connection, then set Active.");
    } catch (e) {
      flash(`Save failed: ${String(e)}`);
    }
  }

  async function testProvider(p: Provider) {
    setTestingId(p.id);
    setTestMsg("Testing connection…");
    try {
      const res = await fetch("/api/providers/test", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ id: p.id }),
      });
      const data = await res.json();
      setTestMsg(data.message || data.error || (data.ok ? "Connected." : "Failed."));
      const list = await fetch("/api/providers").then((r) => r.json());
      setProviders(list.providers || []);
    } catch (e) {
      setTestMsg(`Test failed: ${String(e)}`);
    } finally {
      setTestingId(null);
    }
  }

  async function setActive(id: number) {
    await fetch(`/api/providers/${id}`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ isActive: true }),
    });
    persist({ ...settings, activeProviderId: id });
    const list = await fetch("/api/providers").then((r) => r.json());
    setProviders(list.providers || []);
    flash("Active provider updated.");
  }

  async function deleteProvider(id: number) {
    if (!confirm("Delete this provider profile?")) return;
    await fetch(`/api/providers/${id}`, { method: "DELETE" });
    const list = await fetch("/api/providers").then((r) => r.json());
    setProviders(list.providers || []);
    if (settings.activeProviderId === id) persist({ ...settings, activeProviderId: null });
  }

  async function modelAction(id: number, action: string) {
    await fetch("/api/models", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ id, action }),
    });
    const refresh = async () => {
      const d = await fetch("/api/models").then((r) => r.json());
      setModels(d.models || []);
    };
    if (action === "download") {
      // simulate progressive download
      for (let i = 0; i < 6; i++) {
        await new Promise((r) => setTimeout(r, 500));
        await fetch("/api/models", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ id, action: "progress" }),
        });
        await refresh();
      }
      flash("Model installed. You can now set it Active for offline use.");
    } else {
      await refresh();
      if (action === "activate") {
        const m = models.find((x) => x.id === id);
        if (m?.kind === "llm") persist({ ...settings, activeLocalModelId: id });
        if (m?.kind === "stt") persist({ ...settings, activeSttModelId: id });
        if (m?.kind === "tts") persist({ ...settings, activeTtsModelId: id });
        flash("Active offline model updated.");
      }
    }
  }

  async function toggleQuick(a: QA) {
    const next = quickActions.map((x) => (x.actionKey === a.actionKey ? { ...x, enabled: !x.enabled } : x));
    setQuickActions(next);
    await fetch("/api/quick-actions", {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ actions: next.map((x) => ({ actionKey: x.actionKey, enabled: x.enabled, label: x.label })) }),
    });
  }

  async function requestMic() {
    try {
      await navigator.mediaDevices.getUserMedia({ audio: true });
      flash("Microphone granted. You're all set, Sir.");
    } catch {
      flash("Microphone denied. Enable it in browser/OS settings.");
    }
  }

  async function requestNotify() {
    try {
      const p = await Notification.requestPermission();
      flash(p === "granted" ? "Notifications enabled." : "Notifications not granted.");
    } catch {
      flash("Notifications unavailable here.");
    }
  }

  const filteredTasks = tasks.filter((t) => (logFilter === "all" ? true : t.status === logFilter));
  const activeProvider = providers.find((p) => p.id === settings.activeProviderId) || providers.find((p) => p.isActive) || null;
  const llms = models.filter((m) => m.kind === "llm");
  const stts = models.filter((m) => m.kind === "stt");
  const ttss = models.filter((m) => m.kind === "tts");

  if (!booted) {
    return (
      <div className="fixed inset-0 z-50 grid place-items-center bg-[#020617]">
        <div className="flex flex-col items-center gap-6 px-6 text-center">
          <div className="relative h-44 w-44">
            <div className="absolute inset-0 rounded-full border border-cyan-400/30 anim-spin-slow" />
            <div className="absolute inset-3 rounded-full border border-dashed border-sky-400/40 anim-spin-rev" />
            <div className="absolute inset-8 rounded-full border border-cyan-300/50" />
            <div className="absolute inset-0 grid place-items-center">
              <div className="h-20 w-20 rounded-full bg-gradient-to-br from-cyan-300 via-sky-500 to-blue-700 anim-pulse-core jarvis-glow" />
            </div>
            <div className="absolute inset-0 grid place-items-center">
              <span className="text-2xl font-black tracking-widest text-white jarvis-text-glow">J</span>
            </div>
          </div>
          <div>
            <h1 className="text-3xl font-black tracking-[0.3em] text-cyan-200 jarvis-text-glow">JARVIS</h1>
            <p className="mt-1 text-xs uppercase tracking-[0.25em] text-slate-400">Your Personal AI Assistant</p>
          </div>
          <div className="h-1 w-56 overflow-hidden rounded-full bg-slate-800">
            <div className="h-full rounded-full bg-gradient-to-r from-cyan-400 to-blue-500 anim-boot" />
          </div>
          <p className="text-xs text-slate-500">Initializing hybrid core • voice • automation…</p>
        </div>
      </div>
    );
  }

  return (
    <div className={`${fontScale} min-h-screen pb-28 ${settings.theme === "light" ? "text-slate-900" : ""}`}>
      <div className="mx-auto w-full max-w-xl px-4 pt-4">
        {/* Header */}
        <header className="jarvis-glass flex items-center justify-between rounded-2xl px-4 py-3">
          <div className="flex items-center gap-3">
            <div className={`relative h-10 w-10 shrink-0 overflow-hidden rounded-full bg-gradient-to-br ${accent.core} ${settings.glow && !animOff ? "jarvis-glow" : ""} ${animOff ? "" : "anim-pulse-core"}`}>
              <div className="absolute inset-0 grid place-items-center text-sm font-black text-white">J</div>
            </div>
            <div>
              <p className="text-sm font-black tracking-[0.2em] text-white leading-none">{(settings.assistantName || "JARVIS").toUpperCase()}</p>
              <p className="mt-1 flex items-center gap-1.5 text-[11px] text-slate-400">
                <span className={`inline-block h-1.5 w-1.5 rounded-full ${online ? "bg-emerald-400" : "bg-amber-400"}`} />
                {online ? "Network online" : "Network offline"} • {activeProvider ? `${activeProvider.model}` : "no provider"}
              </p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <span className={`rounded-full border px-2.5 py-1 text-[11px] font-bold uppercase tracking-wider ${effectiveMode === "online" ? "border-emerald-400/40 bg-emerald-400/10 text-emerald-300" : "border-amber-400/40 bg-amber-400/10 text-amber-300"}`}>
              {settings.aiMode === "auto" ? `Hybrid • ${effectiveMode}` : settings.aiMode}
            </span>
          </div>
        </header>

        {notice ? (
          <div className="anim-fade-up mt-3 rounded-xl border border-cyan-400/30 bg-cyan-400/10 px-3 py-2 text-xs text-cyan-100">{notice}</div>
        ) : null}

        {/* HOME */}
        {tab === "home" && (
          <main className="anim-fade-up mt-4 space-y-4">
            {/* AI Core */}
            <section className="jarvis-glass relative overflow-hidden rounded-3xl p-5 text-center">
              <div className="pointer-events-none absolute inset-x-0 top-0 h-10 overflow-hidden opacity-60">
                {!animOff && <div className="h-6 w-full bg-gradient-to-b from-cyan-400/20 to-transparent" style={{ animation: "jarvis-scan 4s linear infinite" }} />}
              </div>
              <p className="text-[11px] uppercase tracking-[0.3em] text-slate-400">Hybrid AI Core</p>
              <div className="relative mx-auto mt-3 h-52 w-52">
                <div className={`absolute inset-0 rounded-full border ${accent.ring} ${animOff ? "" : reducedAnim ? "" : "anim-spin-slow"}`} />
                <div className={`absolute inset-4 rounded-full border border-dashed border-slate-500/50 ${animOff ? "" : reducedAnim ? "" : "anim-spin-rev"}`} />
                <div className="absolute inset-9 rounded-full border border-white/10" />
                <div className="absolute inset-0 grid place-items-center">
                  <button
                    onClick={() => (listening ? stopListening() : startListening())}
                    aria-label="microphone"
                    className={`grid h-24 w-24 place-items-center rounded-full bg-gradient-to-br text-3xl text-white transition ${accent.core} ${settings.glow && !animOff ? "jarvis-glow" : ""} ${listening && !animOff ? "scale-110" : ""}`}
                  >
                    {listening ? "◼" : "🎙"}
                  </button>
                </div>
                {listening && (
                  <div className="absolute -bottom-1 left-1/2 flex h-8 -translate-x-1/2 items-end gap-1">
                    {[0, 1, 2, 3, 4, 5, 6, 7, 8].map((i) => (
                      <span key={i} className="wave-bar w-1 rounded-full bg-cyan-300" style={{ height: `${10 + ((i * 7) % 20)}px`, animationDelay: `${i * 0.08}s` }} />
                    ))}
                  </div>
                )}
              </div>
              <p className={`mt-2 text-sm font-semibold ${accent.text}`}>
                {listening ? `Listening… ${transcript ? `“${transcript}”` : "speak now"}` : speaking ? "Speaking…" : lastResponse.slice(0, 110)}
              </p>
              <p className="mt-1 text-xs text-slate-400">Status: {currentTask}</p>
              <div className="mt-4 grid grid-cols-3 gap-2">
                <button onClick={startListening} className={`rounded-xl px-2 py-2.5 text-xs font-bold ${accent.btn}`}>
                  {listening ? "● Listening" : "Start Listening"}
                </button>
                <button onClick={stopListening} className="rounded-xl border border-slate-600 bg-slate-800/80 px-2 py-2.5 text-xs font-bold text-slate-200">
                  Stop
                </button>
                <button
                  onClick={() => {
                    stopSpeak();
                    setSpeaking(false);
                  }}
                  className="rounded-xl border border-slate-600 bg-slate-800/80 px-2 py-2.5 text-xs font-bold text-slate-200"
                >
                  Stop Speaking
                </button>
              </div>
              <div className="mt-2 grid grid-cols-2 gap-2">
                <button onClick={startWakeWord} className={`rounded-xl border px-2 py-2 text-[11px] font-semibold ${wakeListening ? "border-emerald-400/50 bg-emerald-400/10 text-emerald-200" : "border-cyan-400/30 bg-cyan-400/5 text-cyan-200"}`}>
                  {wakeListening ? `● Wake armed: ${settings.wakePhrase}` : `Wake: ${settings.wakePhrase}`}
                </button>
                <button onClick={() => setConversationOpen((v) => !v)} className="rounded-xl border border-slate-600 bg-slate-800/60 px-2 py-2 text-[11px] font-semibold text-slate-200">
                  {conversationOpen ? "Hide conversation" : "Show conversation"}
                </button>
              </div>
            </section>

            {/* Mode + quick status */}
            <section className="grid grid-cols-3 gap-2">
              {(["auto", "online", "offline"] as const).map((m) => (
                <button
                  key={m}
                  onClick={() => update("aiMode", m)}
                  className={`rounded-2xl border px-2 py-2.5 text-xs font-bold capitalize ${settings.aiMode === m ? "border-cyan-300/60 bg-cyan-400/15 text-cyan-100" : "border-white/10 bg-white/5 text-slate-300"}`}
                >
                  {m === "auto" ? "Auto Hybrid" : m}
                  <span className="block text-[10px] font-normal opacity-70">{m === "auto" ? (online ? "→ online" : "→ offline") : m === effectiveMode ? "● active" : ""}</span>
                </button>
              ))}
            </section>

            {/* Input */}
            <section className="jarvis-glass rounded-2xl p-3">
              <div className="flex gap-2">
                <input
                  value={input}
                  onChange={(e) => setInput(e.target.value)}
                  onKeyDown={(e) => e.key === "Enter" && sendCommand()}
                  placeholder={`Ask ${settings.assistantName}… e.g. "YouTube kholo" / "Rahul ko WhatsApp bhejo"`}
                  className="w-full rounded-xl border border-white/10 bg-black/40 px-3 py-2.5 text-sm text-slate-100 placeholder:text-slate-500 outline-none focus:border-cyan-400/60"
                />
                <button onClick={() => sendCommand()} disabled={busy} className={`shrink-0 rounded-xl px-4 text-sm font-bold disabled:opacity-50 ${accent.btn}`}>
                  {busy ? "…" : "➤"}
                </button>
              </div>
              {pending ? (
                <p className="mt-2 rounded-lg bg-amber-400/10 px-2 py-1.5 text-[11px] text-amber-200">
                  Awaiting follow-up — just reply naturally (context is kept). Example: after “YouTube kholo”, say “Ab Arijit Singh search karo”.
                </p>
              ) : null}
            </section>

            {/* Confirm card */}
            {confirmCard && (
              <section className="rounded-2xl border border-amber-300/40 bg-amber-400/10 p-4">
                <p className="text-sm font-bold text-amber-200">{confirmCard.title} — confirm before send</p>
                <div className="mt-2 rounded-xl bg-black/50 p-3 text-sm text-slate-100">
                  <p className="text-[11px] uppercase tracking-wider text-slate-400">Exact message (preserved verbatim)</p>
                  <p className="mt-1">“{confirmCard.message}”</p>
                  <p className="mt-1 text-[11px] text-slate-400">To: {confirmCard.contact}</p>
                </div>
                <div className="mt-3 grid grid-cols-2 gap-2">
                  <button
                    onClick={() => {
                      if (confirmCard.webUrl) window.open(confirmCard.webUrl, "_blank", "noopener");
                      flash(confirmCard.title.startsWith("Call") ? "Opening dialer — confirm the call on your phone." : "WhatsApp draft opened — press Send in WhatsApp to complete. I never send silently.");
                      setConfirmCard(null);
                    }}
                    className="rounded-xl bg-emerald-400 px-3 py-2 text-sm font-bold text-slate-950"
                  >
                    Confirm & Open
                  </button>
                  <button onClick={() => setConfirmCard(null)} className="rounded-xl border border-white/20 bg-white/5 px-3 py-2 text-sm font-bold text-slate-200">
                    Cancel
                  </button>
                </div>
                <p className="mt-2 text-[11px] text-amber-200/80">I only draft — sending happens after your explicit confirmation in WhatsApp/dialer.</p>
              </section>
            )}

            {/* Quick actions */}
            <section>
              <div className="mb-2 flex items-center justify-between">
                <h2 className="text-xs font-bold uppercase tracking-[0.2em] text-slate-400">Quick Actions</h2>
                <button onClick={() => setTab("settings")} className="text-[11px] text-cyan-300">Customize →</button>
              </div>
              <div className="grid grid-cols-5 gap-2">
                {quickActions.filter((q) => q.enabled).map((q) => (
                  <button key={q.actionKey} onClick={() => handleQuick(q.actionKey, q.label)} className="jarvis-glass flex flex-col items-center gap-1 rounded-2xl px-1 py-3 text-center">
                    <span className="text-xl">{iconFor(q.icon)}</span>
                    <span className="text-[10px] font-semibold leading-tight text-slate-200">{q.label}</span>
                  </button>
                ))}
                {quickActions.filter((q) => q.enabled).length === 0 && (
                  <p className="col-span-5 rounded-xl border border-white/10 bg-white/5 p-3 text-center text-xs text-slate-400">All quick actions hidden. Enable them in Settings → Appearance.</p>
                )}
              </div>
            </section>

            {/* Conversation (compact, not huge) */}
            {conversationOpen && (
              <section className="jarvis-glass rounded-2xl p-3">
                <div className="mb-2 flex items-center justify-between">
                  <h2 className="text-xs font-bold uppercase tracking-[0.2em] text-slate-400">Conversation</h2>
                  <button
                    onClick={async () => {
                      await fetch("/api/messages", { method: "DELETE" });
                      setChatMsgs([]);
                    }}
                    className="text-[11px] text-slate-400"
                  >
                    Clear
                  </button>
                </div>
                <div className="no-scrollbar max-h-72 space-y-2 overflow-y-auto">
                  {chatMsgs.length === 0 && <p className="rounded-xl bg-white/5 p-3 text-xs text-slate-400">No messages yet. Say “Hey JARVIS” or type a command.</p>}
                  {chatMsgs.slice(-30).map((m) => (
                    <div key={m.id} className={`max-w-[90%] rounded-2xl px-3 py-2 text-[13px] leading-relaxed ${m.role === "user" ? "ml-auto bg-cyan-500/20 text-cyan-50" : "bg-white/5 text-slate-200"}`}>
                      <p>{m.content}</p>
                      {m.modeUsed ? <p className="mt-1 text-[10px] opacity-60">via {m.modeUsed}</p> : null}
                    </div>
                  ))}
                  <div ref={chatEndRef} />
                </div>
              </section>
            )}
          </main>
        )}

        {/* LOGS */}
        {tab === "logs" && (
          <main className="anim-fade-up mt-4 space-y-3">
            <div className="jarvis-glass rounded-2xl p-4">
              <h2 className="text-sm font-black tracking-widest text-white">RECENT ACTIVE TASKS</h2>
              <p className="text-[11px] text-slate-400">Only real recorded actions appear here. Nothing is faked.</p>
              <div className="mt-3 flex gap-1.5 overflow-x-auto no-scrollbar">
                {["all", "running", "completed", "failed", "cancelled"].map((f) => (
                  <button key={f} onClick={() => setLogFilter(f)} className={`shrink-0 rounded-full px-3 py-1.5 text-[11px] font-bold capitalize ${logFilter === f ? "bg-cyan-400 text-slate-950" : "bg-white/5 text-slate-300"}`}>
                    {f}
                  </button>
                ))}
              </div>
            </div>
            {filteredTasks.length === 0 && (
              <p className="rounded-2xl border border-white/10 bg-white/5 p-4 text-center text-xs text-slate-400">No tasks yet. Run a command from Home.</p>
            )}
            {filteredTasks.map((t) => (
              <button key={t.id} onClick={() => setSelectedTask(t)} className="jarvis-glass block w-full rounded-2xl p-3 text-left">
                <div className="flex items-center justify-between gap-2">
                  <p className="truncate text-[13px] font-bold text-slate-100">{t.title}</p>
                  <span className={`shrink-0 rounded-full px-2 py-0.5 text-[10px] font-black uppercase ${t.status === "completed" ? "bg-emerald-400/15 text-emerald-300" : t.status === "running" ? "bg-sky-400/15 text-sky-300" : t.status === "failed" ? "bg-rose-400/15 text-rose-300" : "bg-slate-400/15 text-slate-300"}`}>
                    {t.status}
                  </span>
                </div>
                <p className="mt-1 truncate text-[11px] text-slate-400">“{t.input}” • {t.modeUsed} • {new Date(t.startedAt).toLocaleString()}</p>
              </button>
            ))}
            <button
              onClick={async () => {
                if (!confirm("Delete all task logs?")) return;
                await fetch("/api/tasks", { method: "DELETE" });
                setTasks([]);
              }}
              className="w-full rounded-xl border border-rose-400/30 bg-rose-400/10 py-2 text-xs font-bold text-rose-200"
            >
              Delete task logs
            </button>
            {selectedTask && (
              <div className="fixed inset-0 z-40 grid place-items-center bg-black/70 p-4" onClick={() => setSelectedTask(null)}>
                <div className="jarvis-glass w-full max-w-md rounded-2xl p-4" onClick={(e) => e.stopPropagation()}>
                  <h3 className="text-sm font-black text-white">{selectedTask.title}</h3>
                  <p className="mt-1 text-xs text-slate-400">Input: “{selectedTask.input}”</p>
                  <p className="text-xs text-slate-400">Status: {selectedTask.status} • Mode: {selectedTask.modeUsed}</p>
                  <p className="text-xs text-slate-400">Start: {new Date(selectedTask.startedAt).toLocaleString()} {selectedTask.completedAt ? `• End: ${new Date(selectedTask.completedAt).toLocaleString()}` : ""}</p>
                  <div className="mt-3 space-y-1.5">
                    {(selectedTask.steps || []).map((s, i) => (
                      <div key={i} className="rounded-lg bg-white/5 px-2.5 py-1.5 text-xs text-slate-200">
                        <span className="mr-2">{s.status === "completed" ? "✅" : s.status === "pending" ? "⏳" : "•"}</span>
                        {s.label}{s.detail ? <span className="text-slate-400"> — {s.detail}</span> : null}
                      </div>
                    ))}
                  </div>
                  {selectedTask.result ? <p className="mt-3 rounded-lg bg-cyan-400/10 p-2.5 text-xs text-cyan-100">{selectedTask.result}</p> : null}
                  {selectedTask.error ? <p className="mt-2 rounded-lg bg-rose-400/10 p-2.5 text-xs text-rose-200">{selectedTask.error}</p> : null}
                  <div className="mt-3 grid grid-cols-2 gap-2">
                    {selectedTask.status === "running" && (
                      <button
                        onClick={async () => {
                          await fetch(`/api/tasks/${selectedTask.id}`, { method: "PATCH", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ status: "cancelled" }) });
                          setSelectedTask(null);
                          refreshTasksMsgs();
                        }}
                        className="rounded-xl bg-amber-400 py-2 text-xs font-bold text-slate-950"
                      >
                        Cancel task
                      </button>
                    )}
                    <button onClick={() => setSelectedTask(null)} className="rounded-xl border border-white/15 bg-white/5 py-2 text-xs font-bold text-slate-200">
                      Close
                    </button>
                  </div>
                </div>
              </div>
            )}
          </main>
        )}

        {/* PROFILE */}
        {tab === "profile" && (
          <main className="anim-fade-up mt-4 space-y-3">
            <section className="jarvis-glass rounded-3xl p-5 text-center">
              <div className={`mx-auto grid h-16 w-16 place-items-center rounded-full bg-gradient-to-br text-2xl font-black text-white ${accent.core}`}>J</div>
              <h2 className="mt-2 text-lg font-black tracking-widest text-white">{settings.assistantName || "JARVIS"}</h2>
              <p className="text-xs text-slate-400">Your Personal AI Assistant • v2.0.0 • Hybrid build</p>
              <p className="mt-2 inline-block rounded-full bg-white/5 px-3 py-1 text-[11px] text-slate-300">Serving {settings.userName || "Sir"} • {effectiveMode} mode • {online ? "online" : "offline"}</p>
            </section>
            <section className="jarvis-glass rounded-2xl p-4">
              <h3 className="text-xs font-black uppercase tracking-widest text-slate-300">Personalization</h3>
              <div className="mt-3 space-y-2.5">
                <label className="block text-xs text-slate-300">Your name<input value={settings.userName} onChange={(e) => update("userName", e.target.value)} className="mt-1 w-full rounded-xl border border-white/10 bg-black/40 px-3 py-2 text-sm text-white outline-none" /></label>
                <label className="block text-xs text-slate-300">Assistant name<input value={settings.assistantName} onChange={(e) => update("assistantName", e.target.value)} className="mt-1 w-full rounded-xl border border-white/10 bg-black/40 px-3 py-2 text-sm text-white outline-none" /></label>
                <label className="block text-xs text-slate-300">Preferred language
                  <select value={settings.language} onChange={(e) => update("language", e.target.value)} className="mt-1 w-full rounded-xl border border-white/10 bg-black/40 px-3 py-2 text-sm text-white">
                    <option value="auto">Auto (EN + Hindi + Hinglish)</option>
                    <option value="en">English</option>
                    <option value="hinglish">Hinglish</option>
                    <option value="hi">Hindi</option>
                  </select>
                </label>
                <label className="block text-xs text-slate-300">Response style
                  <select value={settings.responseStyle} onChange={(e) => update("responseStyle", e.target.value as JarvisSettings["responseStyle"])} className="mt-1 w-full rounded-xl border border-white/10 bg-black/40 px-3 py-2 text-sm text-white">
                    <option value="jarvis">JARVIS (loyal, concise)</option>
                    <option value="concise">Concise</option>
                    <option value="detailed">Detailed</option>
                  </select>
                </label>
              </div>
            </section>
            <section className="jarvis-glass rounded-2xl p-4">
              <h3 className="text-xs font-black uppercase tracking-widest text-slate-300">Memory & Data</h3>
              <p className="mt-1 text-[11px] text-slate-400">Conversations: {chatMsgs.length} • Tasks: {tasks.length}. Sensitive data is never stored unnecessarily.</p>
              <div className="mt-3 grid grid-cols-2 gap-2">
                <button onClick={async () => { await fetch("/api/messages", { method: "DELETE" }); setChatMsgs([]); flash("Conversation history cleared."); }} className="rounded-xl border border-white/15 bg-white/5 py-2 text-xs font-bold text-slate-200">Clear history</button>
                <button onClick={async () => { await fetch("/api/tasks", { method: "DELETE" }); setTasks([]); flash("Task logs deleted."); }} className="rounded-xl border border-white/15 bg-white/5 py-2 text-xs font-bold text-slate-200">Delete tasks</button>
              </div>
            </section>
            <section className="jarvis-glass rounded-2xl p-4">
              <h3 className="text-xs font-black uppercase tracking-widest text-slate-300">About JARVIS</h3>
              <p className="mt-2 text-xs leading-relaxed text-slate-400">
                Hybrid voice assistant: online intelligence via your Groq / OpenAI-compatible provider, offline fallback with on-device commands, real Android automation through intents + accessibility, multi-step task engine with confirmation for sensitive actions.
              </p>
              <div className="mt-3 rounded-xl bg-black/40 p-3 text-[11px] text-slate-400">
                <p className="font-bold text-slate-200">Android APK & source</p>
                <p className="mt-1">Full native project (Kotlin + Compose + Room + llama.cpp + Vosk + Piper) ships in this repo under <span className="text-cyan-300">/android</span> with GitHub Actions at <span className="text-cyan-300">.github/workflows/build-apk.yml</span>. Push to GitHub → Actions → download the APK artifact. See README for setup, permissions, offline models.</p>
                <div className="mt-2 flex gap-2">
                  <a href="/api/android" target="_blank" className="rounded-lg bg-cyan-400 px-3 py-1.5 font-bold text-slate-950">View build manifest</a>
                  <button onClick={() => setTab("settings")} className="rounded-lg border border-white/15 px-3 py-1.5 text-slate-200">Open AI setup</button>
                </div>
              </div>
            </section>
          </main>
        )}

        {/* SETTINGS */}
        {tab === "settings" && (
          <main className="anim-fade-up mt-4 space-y-3">
            <div className="no-scrollbar flex gap-1.5 overflow-x-auto">
              {["AI", "Voice", "Appearance", "Automation", "Permissions", "General"].map((s) => (
                <button key={s} onClick={() => setSettingsTab(s)} className={`shrink-0 rounded-full px-3.5 py-1.5 text-xs font-bold ${settingsTab === s ? "bg-cyan-400 text-slate-950" : "bg-white/5 text-slate-300"}`}>
                  {s}
                </button>
              ))}
            </div>

            {settingsTab === "AI" && (
              <div className="space-y-3">
                <section className="jarvis-glass rounded-2xl p-4">
                  <h3 className="text-xs font-black uppercase tracking-widest text-slate-200">AI Mode</h3>
                  <div className="mt-2 grid grid-cols-3 gap-2">
                    {(["auto", "online", "offline"] as const).map((m) => (
                      <button key={m} onClick={() => update("aiMode", m)} className={`rounded-xl border py-2 text-xs font-bold capitalize ${settings.aiMode === m ? "border-cyan-300/60 bg-cyan-400/15 text-cyan-100" : "border-white/10 bg-white/5 text-slate-300"}`}>
                        {m === "auto" ? "Auto Hybrid" : m}
                      </button>
                    ))}
                  </div>
                  <p className="mt-2 text-[11px] text-slate-400">Auto: online provider when internet works, else offline model. Online failures fall back to offline automatically.</p>
                  <div className="mt-3 space-y-2">
                    <Toggle label="Fast Response Mode" desc="Lower latency: fewer tokens, faster STT startup, instant feedback" value={settings.fastResponse} onChange={(v) => update("fastResponse", v)} />
                    <label className="block text-xs text-slate-300">Performance
                      <select value={settings.performance} onChange={(e) => update("performance", e.target.value as JarvisSettings["performance"])} className="mt-1 w-full rounded-xl border border-white/10 bg-black/40 px-3 py-2 text-sm text-white">
                        <option value="balanced">Balanced</option>
                        <option value="fast">Fast</option>
                        <option value="max">Maximum Responsiveness</option>
                      </select>
                    </label>
                  </div>
                </section>

                <section className="jarvis-glass rounded-2xl p-4">
                  <div className="flex items-center justify-between">
                    <h3 className="text-xs font-black uppercase tracking-widest text-slate-200">Providers (Groq / OpenAI-compatible)</h3>
                    <button onClick={() => { setEditingProvider({ name: "", type: "groq", baseUrl: "", model: "", apiKey: "" }); setShowProviderForm(true); }} className="rounded-lg bg-cyan-400 px-2.5 py-1 text-[11px] font-bold text-slate-950">+ Add</button>
                  </div>
                  <p className="mt-1 text-[11px] text-slate-500">Fields stay empty until you enter your own keys. Keys are stored server-side, never in logs.</p>
                  <div className="mt-3 space-y-2">
                    {providers.length === 0 && <p className="rounded-xl bg-white/5 p-3 text-xs text-slate-400">No provider yet — add your Groq or OpenAI-compatible endpoint. Offline mode still works.</p>}
                    {providers.map((p) => (
                      <div key={p.id} className={`rounded-xl border p-3 ${settings.activeProviderId === p.id || p.isActive ? "border-cyan-300/40 bg-cyan-400/5" : "border-white/10 bg-black/30"}`}>
                        <div className="flex items-center justify-between gap-2">
                          <p className="text-sm font-bold text-white">{p.name} <span className="ml-1 rounded bg-white/10 px-1.5 py-0.5 text-[10px] text-slate-300">{p.type} • {p.model}</span></p>
                          {p.lastTestOk ? <span className="text-[10px] text-emerald-300">● tested</span> : null}
                        </div>
                        <p className="mt-1 truncate text-[11px] text-slate-500">{p.baseUrl || "(default base URL)"} • key {p.apiKeyMasked || "••••"}</p>
                        <div className="mt-2 flex flex-wrap gap-1.5">
                          <button onClick={() => testProvider(p)} className="rounded-lg border border-white/15 px-2.5 py-1 text-[11px] font-bold text-slate-200">{testingId === p.id ? "Testing…" : "Test"}</button>
                          <button onClick={() => setActive(p.id)} className="rounded-lg bg-cyan-400 px-2.5 py-1 text-[11px] font-bold text-slate-950">Set Active</button>
                          <button onClick={() => { setEditingProvider({ id: p.id, name: p.name, type: p.type, baseUrl: p.baseUrl, model: p.model, apiKey: "" }); setShowProviderForm(true); }} className="rounded-lg border border-white/15 px-2.5 py-1 text-[11px] text-slate-300">Edit</button>
                          <button onClick={() => deleteProvider(p.id)} className="rounded-lg border border-rose-400/30 px-2.5 py-1 text-[11px] text-rose-300">Delete</button>
                        </div>
                      </div>
                    ))}
                    {testMsg ? <p className="rounded-lg bg-white/5 p-2 text-[11px] text-slate-300">{testMsg}</p> : null}
                  </div>
                </section>

                <section className="jarvis-glass rounded-2xl p-4">
                  <h3 className="text-xs font-black uppercase tracking-widest text-slate-200">Offline models (on-device)</h3>
                  <p className="mt-1 text-[11px] text-slate-500">Lightweight quantized models via llama.cpp. Nothing downloads without your consent.</p>
                  {llms.map((m) => (
                    <ModelRow key={m.id} m={m} onAction={modelAction} />
                  ))}
                  <h3 className="mt-4 text-xs font-black uppercase tracking-widest text-slate-200">Voice models (offline STT/TTS)</h3>
                  {stts.map((m) => (
                    <ModelRow key={m.id} m={m} onAction={modelAction} />
                  ))}
                  {ttss.map((m) => (
                    <ModelRow key={m.id} m={m} onAction={modelAction} />
                  ))}
                </section>
              </div>
            )}

            {settingsTab === "Voice" && (
              <div className="jarvis-glass space-y-3 rounded-2xl p-4">
                <Toggle label="Voice input" desc="Microphone + speech recognition" value={settings.voiceInput} onChange={(v) => update("voiceInput", v)} />
                <Toggle label="Voice output" desc="Spoken replies (TTS)" value={settings.voiceOutput} onChange={(v) => update("voiceOutput", v)} />
                <Toggle label="Push-to-Talk" desc="Mic button hold-to-talk style" value={settings.pushToTalk} onChange={(v) => update("pushToTalk", v)} />
                <Toggle label="Continuous listening" desc="Keep mic armed after each command" value={settings.continuous} onChange={(v) => update("continuous", v)} />
                <Toggle label="Wake word" desc={`Say "${settings.wakePhrase}" to wake`} value={settings.wakeWord} onChange={(v) => update("wakeWord", v)} />
                <label className="block text-xs text-slate-300">Wake phrase<input value={settings.wakePhrase} onChange={(e) => update("wakePhrase", e.target.value)} className="mt-1 w-full rounded-xl border border-white/10 bg-black/40 px-3 py-2 text-sm text-white" /></label>
                <label className="block text-xs text-slate-300">Language
                  <select value={settings.speechLang} onChange={(e) => update("speechLang", e.target.value)} className="mt-1 w-full rounded-xl border border-white/10 bg-black/40 px-3 py-2 text-sm text-white">
                    <option value="en-IN">English (India)</option>
                    <option value="en-US">English (US)</option>
                    <option value="hi-IN">Hindi</option>
                  </select>
                </label>
                <label className="block text-xs text-slate-300">Voice
                  <select value={settings.speechVoice} onChange={(e) => update("speechVoice", e.target.value)} className="mt-1 w-full rounded-xl border border-white/10 bg-black/40 px-3 py-2 text-sm text-white">
                    <option value="">System default</option>
                    {voices.map((v) => (
                      <option key={v.voiceURI} value={v.voiceURI}>{v.name} ({v.lang})</option>
                    ))}
                  </select>
                </label>
                <Slider label={`Speed: ${settings.speechRate.toFixed(2)}`} value={settings.speechRate} min={0.5} max={2} step={0.05} onChange={(v) => update("speechRate", v)} />
                <Slider label={`Pitch: ${settings.speechPitch.toFixed(2)}`} value={settings.speechPitch} min={0.5} max={2} step={0.05} onChange={(v) => update("speechPitch", v)} />
                <Slider label={`Volume: ${Math.round(settings.speechVolume * 100)}%`} value={settings.speechVolume} min={0} max={1} step={0.05} onChange={(v) => update("speechVolume", v)} />
                <div className="grid grid-cols-2 gap-2">
                  <button onClick={() => doSpeak(`Hello ${settings.userName}. I am ${settings.assistantName}, online and ready.`)} className="rounded-xl bg-cyan-400 py-2 text-xs font-bold text-slate-950">Preview voice</button>
                  <button onClick={() => { stopSpeak(); setSpeaking(false); }} className="rounded-xl border border-white/15 py-2 text-xs font-bold text-slate-200">Stop</button>
                </div>
              </div>
            )}

            {settingsTab === "Appearance" && (
              <div className="jarvis-glass space-y-3 rounded-2xl p-4">
                <label className="block text-xs text-slate-300">Theme
                  <select value={settings.theme} onChange={(e) => update("theme", e.target.value as JarvisSettings["theme"])} className="mt-1 w-full rounded-xl border border-white/10 bg-black/40 px-3 py-2 text-sm text-white">
                    <option value="dark">Dark (JARVIS)</option>
                    <option value="light">Light</option>
                    <option value="system">System</option>
                  </select>
                </label>
                <div>
                  <p className="text-xs text-slate-300">Accent</p>
                  <div className="mt-1.5 flex gap-2">
                    {Object.keys(ACCENTS).map((k) => (
                      <button key={k} onClick={() => update("accent", k as JarvisSettings["accent"])} className={`h-9 w-9 rounded-full bg-gradient-to-br ${ACCENTS[k].core} ${settings.accent === k ? "ring-2 ring-white" : "opacity-70"}`} aria-label={k} />
                    ))}
                  </div>
                </div>
                <Toggle label="Neon glow" value={settings.glow} onChange={(v) => update("glow", v)} />
                <label className="block text-xs text-slate-300">Animation
                  <select value={settings.animation} onChange={(e) => update("animation", e.target.value as JarvisSettings["animation"])} className="mt-1 w-full rounded-xl border border-white/10 bg-black/40 px-3 py-2 text-sm text-white">
                    <option value="full">Full</option>
                    <option value="reduced">Reduced (fast)</option>
                    <option value="off">Off (max performance)</option>
                  </select>
                </label>
                <label className="block text-xs text-slate-300">Font size
                  <select value={settings.fontSize} onChange={(e) => update("fontSize", e.target.value as JarvisSettings["fontSize"])} className="mt-1 w-full rounded-xl border border-white/10 bg-black/40 px-3 py-2 text-sm text-white">
                    <option value="small">Small</option>
                    <option value="medium">Medium</option>
                    <option value="large">Large</option>
                  </select>
                </label>
                <div>
                  <p className="text-xs font-bold text-slate-200">Quick actions</p>
                  <div className="mt-2 space-y-1.5">
                    {quickActions.map((q) => (
                      <div key={q.actionKey} className="flex items-center justify-between rounded-xl bg-white/5 px-3 py-2">
                        <span className="text-xs text-slate-200">{iconFor(q.icon)} {q.label}</span>
                        <button onClick={() => toggleQuick(q)} className={`rounded-full px-3 py-1 text-[11px] font-bold ${q.enabled ? "bg-emerald-400 text-slate-950" : "bg-white/10 text-slate-400"}`}>
                          {q.enabled ? "On" : "Off"}
                        </button>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            )}

            {settingsTab === "Automation" && (
              <div className="jarvis-glass space-y-3 rounded-2xl p-4">
                <Toggle label="Automation enabled" desc="App launching, intents, accessibility actions" value={settings.automationEnabled} onChange={(v) => update("automationEnabled", v)} />
                <Toggle label="Confirm sensitive actions" desc="Calls, messages, settings changes need confirmation" value={settings.confirmSensitive} onChange={(v) => update("confirmSensitive", v)} />
                <Toggle label="Background operation" desc="Foreground service + persistent notification (Android)" value={settings.backgroundEnabled} onChange={(v) => update("backgroundEnabled", v)} />
                <div className="rounded-xl bg-white/5 p-3 text-[11px] leading-relaxed text-slate-400">
                  Android: enable Accessibility Service (JARVIS → System Actions) for Back/Home/Scroll/Type support. Grant apps one-by-one — I never bypass security or claim success unless the action verifies.
                </div>
              </div>
            )}

            {settingsTab === "Permissions" && (
              <div className="space-y-2">
                {[
                  { t: "Microphone", d: "Voice input + wake word. Requested when you tap Start Listening.", fn: requestMic, btn: "Request mic" },
                  { t: "Notifications", d: "Task completion + background status.", fn: requestNotify, btn: "Enable" },
                  { t: "Accessibility Service", d: "Android only: Settings → Accessibility → JARVIS → Enable. Needed for scroll/type/back.", fn: () => flash("On Android: Settings → Accessibility → JARVIS → Enable."), btn: "How to" },
                  { t: "Contacts / Phone", d: "Only for call/message features. Asked when you use them.", fn: () => flash("Contacts are read only when you name a contact."), btn: "Info" },
                  { t: "Storage", d: "Offline model downloads use modern scoped storage.", fn: () => flash("Models show exact MB before download."), btn: "Info" },
                ].map((p) => (
                  <div key={p.t} className="jarvis-glass flex items-center justify-between gap-3 rounded-2xl p-3">
                    <div>
                      <p className="text-sm font-bold text-white">{p.t}</p>
                      <p className="text-[11px] text-slate-400">{p.d}</p>
                    </div>
                    <button onClick={p.fn} className="shrink-0 rounded-xl bg-cyan-400 px-3 py-1.5 text-[11px] font-bold text-slate-950">{p.btn}</button>
                  </div>
                ))}
              </div>
            )}

            {settingsTab === "General" && (
              <div className="jarvis-glass space-y-3 rounded-2xl p-4">
                <Toggle label="Notifications" value={settings.notifications} onChange={(v) => update("notifications", v)} />
                <Toggle label="Haptics" value={settings.haptics} onChange={(v) => update("haptics", v)} />
                <Toggle label="Sound effects" value={settings.sounds} onChange={(v) => update("sounds", v)} />
                <div className="grid grid-cols-2 gap-2">
                  <button
                    onClick={async () => {
                      if (!confirm("Reset all preferences?")) return;
                      persist({ ...DEFAULT_SETTINGS });
                      flash("Preferences reset.");
                    }}
                    className="rounded-xl border border-white/15 py-2 text-xs font-bold text-slate-200"
                  >
                    Reset preferences
                  </button>
                  <button
                    onClick={async () => {
                      await fetch("/api/messages", { method: "DELETE" });
                      await fetch("/api/tasks", { method: "DELETE" });
                      setChatMsgs([]);
                      setTasks([]);
                      flash("All local data cleared.");
                    }}
                    className="rounded-xl border border-rose-400/30 bg-rose-400/10 py-2 text-xs font-bold text-rose-200"
                  >
                    Erase local data
                  </button>
                </div>
                <p className="text-[11px] text-slate-500">JARVIS v2.0.0 • Next.js + Postgres control plane • Native Android project in /android • {settingsLoaded ? "settings synced" : "loading…"}</p>
              </div>
            )}
          </main>
        )}
      </div>

      {/* Provider modal */}
      {showProviderForm && (
        <div className="fixed inset-0 z-40 grid place-items-center bg-black/70 p-4" onClick={() => setShowProviderForm(false)}>
          <div className="jarvis-glass w-full max-w-md rounded-2xl p-4" onClick={(e) => e.stopPropagation()}>
            <h3 className="text-sm font-black text-white">{editingProvider.id ? "Edit provider" : "Add provider"}</h3>
            <div className="mt-3 space-y-2.5">
              <label className="block text-xs text-slate-300">Provider name<input value={editingProvider.name || ""} onChange={(e) => setEditingProvider((p) => ({ ...p, name: e.target.value }))} placeholder="e.g. My Groq" className="mt-1 w-full rounded-xl border border-white/10 bg-black/40 px-3 py-2 text-sm text-white outline-none" /></label>
              <label className="block text-xs text-slate-300">Type
                <select value={editingProvider.type || "groq"} onChange={(e) => setEditingProvider((p) => ({ ...p, type: e.target.value }))} className="mt-1 w-full rounded-xl border border-white/10 bg-black/40 px-3 py-2 text-sm text-white">
                  <option value="groq">Groq-compatible</option>
                  <option value="openai">OpenAI-compatible</option>
                  <option value="custom">Custom endpoint</option>
                </select>
              </label>
              <label className="block text-xs text-slate-300">Base URL (optional — leave empty for default)<input value={editingProvider.baseUrl || ""} onChange={(e) => setEditingProvider((p) => ({ ...p, baseUrl: e.target.value }))} placeholder="https://api.groq.com/openai/v1" className="mt-1 w-full rounded-xl border border-white/10 bg-black/40 px-3 py-2 text-sm text-white outline-none" /></label>
              <label className="block text-xs text-slate-300">Model name<input value={editingProvider.model || ""} onChange={(e) => setEditingProvider((p) => ({ ...p, model: e.target.value }))} placeholder="e.g. llama-3.3-70b-versatile" className="mt-1 w-full rounded-xl border border-white/10 bg-black/40 px-3 py-2 text-sm text-white outline-none" /></label>
              <label className="block text-xs text-slate-300">API key<input type="password" value={editingProvider.apiKey || ""} onChange={(e) => setEditingProvider((p) => ({ ...p, apiKey: e.target.value }))} placeholder="Enter your key — never prefilled" className="mt-1 w-full rounded-xl border border-white/10 bg-black/40 px-3 py-2 text-sm text-white outline-none" /></label>
            </div>
            <div className="mt-4 grid grid-cols-2 gap-2">
              <button onClick={saveProviderForm} className="rounded-xl bg-cyan-400 py-2.5 text-sm font-bold text-slate-950">Save Configuration</button>
              <button onClick={() => setShowProviderForm(false)} className="rounded-xl border border-white/15 py-2.5 text-sm font-bold text-slate-200">Cancel</button>
            </div>
          </div>
        </div>
      )}

      {/* Bottom nav */}
      <nav className="fixed inset-x-0 bottom-0 z-30 border-t border-cyan-400/15 bg-[#020617]/95 backdrop-blur">
        <div className="mx-auto grid max-w-xl grid-cols-4">
          {([["home", "⌂", "Home"], ["logs", "☰", "Logs"], ["profile", "◉", "Profile"], ["settings", "⚙", "Settings"]] as const).map(([k, icon, label]) => (
            <button key={k} onClick={() => setTab(k)} className={`flex flex-col items-center gap-0.5 py-2.5 text-[11px] font-bold ${tab === k ? "text-cyan-300" : "text-slate-500"}`}>
              <span className="text-lg leading-none">{icon}</span>
              {label}
              {tab === k && <span className="h-1 w-8 rounded-full bg-cyan-400" />}
            </button>
          ))}
        </div>
      </nav>
    </div>
  );
}

function Toggle({ label, desc, value, onChange }: { label: string; desc?: string; value: boolean; onChange: (v: boolean) => void }) {
  return (
    <div className="flex items-center justify-between gap-3">
      <div>
        <p className="text-[13px] font-semibold text-slate-100">{label}</p>
        {desc ? <p className="text-[11px] text-slate-500">{desc}</p> : null}
      </div>
      <button onClick={() => onChange(!value)} className={`relative h-7 w-12 shrink-0 rounded-full transition ${value ? "bg-cyan-400" : "bg-slate-700"}`} aria-pressed={value}>
        <span className={`absolute top-1 h-5 w-5 rounded-full bg-white transition-all ${value ? "left-6" : "left-1"}`} />
      </button>
    </div>
  );
}

function Slider({ label, value, min, max, step, onChange }: { label: string; value: number; min: number; max: number; step: number; onChange: (v: number) => void }) {
  return (
    <label className="block text-xs text-slate-300">
      {label}
      <input type="range" min={min} max={max} step={step} value={value} onChange={(e) => onChange(Number(e.target.value))} className="mt-1 w-full accent-cyan-400" />
    </label>
  );
}

function ModelRow({ m, onAction }: { m: DevModel; onAction: (id: number, a: string) => void }) {
  return (
    <div className="mt-2 rounded-xl border border-white/10 bg-black/30 p-3">
      <div className="flex items-center justify-between gap-2">
        <p className="text-[13px] font-bold text-white">{m.name}</p>
        <span className={`shrink-0 rounded-full px-2 py-0.5 text-[10px] font-black uppercase ${m.status === "installed" ? "bg-emerald-400/15 text-emerald-300" : m.status === "downloading" ? "bg-sky-400/15 text-sky-300" : "bg-white/10 text-slate-300"}`}>
          {m.status} {m.isActive ? "• active" : ""}
        </span>
      </div>
      <p className="mt-0.5 text-[11px] text-slate-400">{m.description} • {m.sizeMb} MB</p>
      {m.status === "downloading" && (
        <div className="mt-2 h-1.5 overflow-hidden rounded-full bg-slate-800">
          <div className="h-full bg-gradient-to-r from-cyan-400 to-blue-500" style={{ width: `${m.progress}%` }} />
        </div>
      )}
      <div className="mt-2 flex gap-1.5">
        {m.status === "available" && <button onClick={() => onAction(m.id, "download")} className="rounded-lg bg-cyan-400 px-2.5 py-1 text-[11px] font-bold text-slate-950">Download</button>}
        {m.status === "installed" && !m.isActive && <button onClick={() => onAction(m.id, "activate")} className="rounded-lg bg-emerald-400 px-2.5 py-1 text-[11px] font-bold text-slate-950">Set Active</button>}
        {m.status !== "available" && <button onClick={() => onAction(m.id, "delete")} className="rounded-lg border border-rose-400/30 px-2.5 py-1 text-[11px] text-rose-300">Delete</button>}
      </div>
    </div>
  );
}
