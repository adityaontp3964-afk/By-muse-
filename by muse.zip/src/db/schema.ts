import {
  pgTable,
  serial,
  text,
  varchar,
  boolean,
  integer,
  timestamp,
  jsonb,
} from "drizzle-orm/pg-core";

export const providers = pgTable("jarvis_providers", {
  id: serial("id").primaryKey(),
  name: varchar("name", { length: 120 }).notNull(),
  type: varchar("type", { length: 40 }).notNull().default("groq"),
  baseUrl: text("base_url").notNull().default(""),
  model: varchar("model", { length: 200 }).notNull().default(""),
  apiKey: text("api_key").notNull().default(""),
  isActive: boolean("is_active").notNull().default(false),
  lastTestedAt: timestamp("last_tested_at"),
  lastTestOk: boolean("last_test_ok").default(false),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const tasks = pgTable("jarvis_tasks", {
  id: serial("id").primaryKey(),
  title: varchar("title", { length: 240 }).notNull(),
  input: text("input").notNull().default(""),
  status: varchar("status", { length: 24 }).notNull().default("completed"),
  modeUsed: varchar("mode_used", { length: 24 }).notNull().default("offline"),
  steps: jsonb("steps").$type<
    { label: string; status: string; detail?: string; at?: string }[]
  >().default([]),
  result: text("result").default(""),
  error: text("error").default(""),
  startedAt: timestamp("started_at").notNull().defaultNow(),
  completedAt: timestamp("completed_at"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const messages = pgTable("jarvis_messages", {
  id: serial("id").primaryKey(),
  role: varchar("role", { length: 16 }).notNull(),
  content: text("content").notNull(),
  modeUsed: varchar("mode_used", { length: 24 }).default("offline"),
  taskId: integer("task_id"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const quickActions = pgTable("jarvis_quick_actions", {
  id: serial("id").primaryKey(),
  actionKey: varchar("action_key", { length: 80 }).notNull().unique(),
  label: varchar("label", { length: 120 }).notNull(),
  icon: varchar("icon", { length: 40 }).notNull().default("zap"),
  enabled: boolean("enabled").notNull().default(true),
  sortOrder: integer("sort_order").notNull().default(0),
});

export const appSettings = pgTable("jarvis_settings", {
  key: varchar("key", { length: 120 }).primaryKey(),
  value: jsonb("value"),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
});

export const deviceModels = pgTable("jarvis_device_models", {
  id: serial("id").primaryKey(),
  kind: varchar("kind", { length: 16 }).notNull(),
  name: varchar("name", { length: 160 }).notNull(),
  description: text("description").default(""),
  sizeMb: integer("size_mb").notNull().default(0),
  downloadUrl: text("download_url").default(""),
  status: varchar("status", { length: 24 }).notNull().default("available"),
  progress: integer("progress").notNull().default(0),
  isActive: boolean("is_active").notNull().default(false),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});
