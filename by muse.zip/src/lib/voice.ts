"use client";

export function getVoices(): SpeechSynthesisVoice[] {
  if (typeof window === "undefined" || !("speechSynthesis" in window)) return [];
  return window.speechSynthesis.getVoices();
}

export function speak(
  text: string,
  opts: { rate?: number; pitch?: number; volume?: number; lang?: string; voiceURI?: string } = {}
) {
  if (typeof window === "undefined" || !("speechSynthesis" in window)) return false;
  window.speechSynthesis.cancel();
  const u = new SpeechSynthesisUtterance(text);
  u.rate = opts.rate ?? 1;
  u.pitch = opts.pitch ?? 1;
  u.volume = opts.volume ?? 1;
  u.lang = opts.lang ?? "en-IN";
  if (opts.voiceURI) {
    const v = window.speechSynthesis.getVoices().find((x) => x.voiceURI === opts.voiceURI);
    if (v) u.voice = v;
  }
  window.speechSynthesis.speak(u);
  return true;
}

export function stopSpeak() {
  if (typeof window !== "undefined" && "speechSynthesis" in window) {
    window.speechSynthesis.cancel();
  }
}

export type RecHandlers = {
  onResult: (text: string, isFinal: boolean) => void;
  onEnd?: () => void;
  onError?: (msg: string) => void;
  onStart?: () => void;
};

export function createRecognizer(lang: string, handlers: RecHandlers) {
  const SR =
    typeof window !== "undefined"
      ? // eslint-disable-next-line @typescript-eslint/no-explicit-any
        (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition
      : null;
  if (!SR) return null;
  const rec = new SR();
  rec.lang = lang;
  rec.interimResults = true;
  rec.continuous = false;
  rec.maxAlternatives = 1;
  rec.onresult = (e: unknown) => {
    const ev = e as { results: { [i: number]: { [j: number]: { transcript: string } }; length: number }; resultIndex: number };
    const res = ev.results[ev.resultIndex];
    const transcript = res?.[0]?.transcript ?? "";
    const isFinal = (res as unknown as { isFinal: boolean })?.isFinal ?? true;
    handlers.onResult(transcript, isFinal);
  };
  rec.onerror = (e: unknown) => {
    const err = (e as { error?: string })?.error || "recognition error";
    handlers.onError?.(err);
  };
  rec.onend = () => handlers.onEnd?.();
  rec.onstart = () => handlers.onStart?.();
  return rec as { start: () => void; stop: () => void; abort: () => void };
}
