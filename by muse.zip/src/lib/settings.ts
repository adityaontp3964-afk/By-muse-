export interface JarvisSettings {
  aiMode: "auto" | "online" | "offline";
  activeProviderId: number | null;
  fastResponse: boolean;
  performance: "balanced" | "fast" | "max";
  responseStyle: "concise" | "detailed" | "jarvis";
  responseLength: "short" | "medium" | "long";
  theme: "dark" | "light" | "system";
  accent: "cyan" | "blue" | "violet" | "emerald" | "amber";
  glow: boolean;
  animation: "full" | "reduced" | "off";
  fontSize: "small" | "medium" | "large";
  voiceInput: boolean;
  voiceOutput: boolean;
  speechRate: number;
  speechPitch: number;
  speechVolume: number;
  speechLang: string;
  speechVoice: string;
  wakeWord: boolean;
  wakePhrase: string;
  pushToTalk: boolean;
  continuous: boolean;
  confirmSensitive: boolean;
  automationEnabled: boolean;
  backgroundEnabled: boolean;
  notifications: boolean;
  haptics: boolean;
  sounds: boolean;
  assistantName: string;
  userName: string;
  language: string;
  activeLocalModelId: number | null;
  activeSttModelId: number | null;
  activeTtsModelId: number | null;
}

export const DEFAULT_SETTINGS: JarvisSettings = {
  aiMode: "auto",
  activeProviderId: null,
  fastResponse: true,
  performance: "fast",
  responseStyle: "jarvis",
  responseLength: "medium",
  theme: "dark",
  accent: "cyan",
  glow: true,
  animation: "full",
  fontSize: "medium",
  voiceInput: true,
  voiceOutput: true,
  speechRate: 1,
  speechPitch: 1,
  speechVolume: 1,
  speechLang: "en-IN",
  speechVoice: "",
  wakeWord: false,
  wakePhrase: "Hey JARVIS",
  pushToTalk: true,
  continuous: false,
  confirmSensitive: true,
  automationEnabled: true,
  backgroundEnabled: false,
  notifications: true,
  haptics: true,
  sounds: true,
  assistantName: "JARVIS",
  userName: "Sir",
  language: "auto",
  activeLocalModelId: null,
  activeSttModelId: null,
  activeTtsModelId: null,
};
