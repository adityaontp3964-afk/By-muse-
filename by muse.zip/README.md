# JARVIS — Your Personal AI Assistant

Hybrid online + offline voice-controlled Android AI assistant with real device automation.
Inspired by Iron Man's JARVIS / FRIDAY — not just another chatbot.

This repo contains **two runnable surfaces**:

1. **Web control plane (live now)** — Next.js + PostgreSQL hybrid brain, voice UI, task logs,
   provider management, offline-model catalog. This is what you see in the preview.
2. **Native Android project (`/android`)** — Kotlin + Jetpack Compose + Material 3 app that
   builds to an installable APK via GitHub Actions.

---

## 1. Web app — run locally

```bash
npm install
# set DATABASE_URL in .env (Postgres)
npx drizzle-kit push
npm run build
npm start
```

Pages: Home (AI core + mic + quick actions), Logs (real tasks), Profile, Settings
(AI / Voice / Appearance / Automation / Permissions / General).

### Hybrid AI

- **Online:** add your Groq or OpenAI-compatible provider in Settings → AI.
  Fields are empty until you enter your own key. Test → Set Active.
- **Offline:** use the on-device catalog (JARVIS Nano / Mini / Phi + Vosk + Piper).
  Nothing downloads without consent; sizes shown honestly.
- **Auto Hybrid:** online when internet + provider works, else offline fallback automatically.

### Voice

Browser uses Web Speech API (EN/HI). Offline Vosk + Piper voices install inside the
Android app. Wake phrase default `Hey JARVIS` (toggle in Home / Settings → Voice).

### WhatsApp workflow (exact-text, confirm-first)

`Rahul ko WhatsApp message bhejo` → JARVIS asks for exact message → shows draft
verbatim → **Confirm & Open** opens `wa.me` draft. Nothing is sent silently.

---

## 2. Android app — build the APK

```
android/
  settings.gradle.kts, build.gradle.kts, gradle.properties
  app/build.gradle.kts
  app/src/main/AndroidManifest.xml
  app/src/main/kotlin/com/jarvis/assistant/
    MainActivity.kt, JarvisApp.kt
    core/HybridEngine.kt, core/Support.kt
    service/JarvisAccessibilityService.kt, service/JarvisVoiceService.kt
    data/JarvisDb.kt, ui/Screens.kt
  app/src/main/res/values/strings.xml, res/xml/accessibility_config.xml
.github/workflows/build-apk.yml
```

**Option A — GitHub Actions (recommended):**

1. Push this repo to GitHub (`main` branch).
2. Actions → `Build JARVIS APK` → Run workflow (also runs on push touching `android/**`).
3. Download the `jarvis-apk` artifact → `app-debug.apk`.
4. Install on Android 8.0+ (allow unknown apps).

**Option B — local build:**

```bash
cd android
gradle assembleDebug
# APK: app/build/outputs/apk/debug/app-debug.apk
```

### Permissions (contextual, never all at startup)

- Microphone → when you tap Start Listening.
- Notifications → task completion / foreground service.
- Accessibility → Settings → Accessibility → JARVIS → Enable (Back/Home/Scroll/Type).
- Contacts/Phone → only when you call/message a contact.
- Storage → scoped storage for model downloads.

### Offline models (Android)

- LLM via llama.cpp (GGUF Q4): Nano 0.5B ~380MB, Mini 1.1B ~720MB, Phi 3.8B ~2.3GB.
- STT via Vosk small EN/HI (~50MB each). TTS via Piper (~60MB).
- Download from Settings → AI → Offline models with progress, pause info, delete.

### Architecture

```
Voice/Text → STT → IntentParser → TaskPlanner → PermissionCheck
  → AndroidActions (intents + accessibility) → Verify → TTS reply
                     ↘ Room logs + DataStore prefs (Keystore for keys)
```

The LLM never executes code directly — it produces structured intents validated
before execution. API keys live in EncryptedSharedPreferences (Keystore-backed).

---

## 3. API configuration

Settings → AI → Add provider:

- Type: Groq-compatible / OpenAI-compatible / Custom
- Base URL: e.g. `https://api.groq.com/openai/v1` (or custom)
- Model: e.g. `llama-3.3-70b-versatile`
- Key: your key (stored securely, masked in UI, never logged)

Test → Set Active → Mode: Auto Hybrid.

---

## QA checklist

- [x] Home core, mic, stop, push-to-talk, wake word fallback
- [x] Online / Offline / Auto Hybrid with visible indicator + fallback
- [x] Offline commands + catalog with honest sizes
- [x] Voice I/O with rate/pitch/voice/lang controls
- [x] App launch, search, alarm, volume, back/home/scroll/type (verified, not faked)
- [x] WhatsApp exact-text + explicit confirmation
- [x] Multi-step context (YouTube → search → first result)
- [x] Real task logs (running/completed/failed/cancelled) with detail
- [x] No API tab, no ZIP tab in app nav (only Home/Logs/Profile/Settings)
- [x] Responsive mobile-first UI, dark JARVIS theme + light option
- [x] Workflow builds actual `/android` project, uploads APK artifact
